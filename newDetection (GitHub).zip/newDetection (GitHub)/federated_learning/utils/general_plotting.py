import csv
import os
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import MaxNLocator, PercentFormatter

import pandas as pd
from collections import defaultdict

def plot_accuracy_epochs(accuracies, epochs, experiment_id, plot_dir, percentage_malicious, label):
    plt.figure(figsize=(10, 5))
    plt.plot(epochs, accuracies, label=label)
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy (%)')
    plt.title(f'Malicious Clients {percentage_malicious}% Accuracy vs. Epochs')
    plt.legend()
    plt.grid(True)
    plot_path = f'{plot_dir}/accuracy_epochs_Exp{experiment_id}_{label}_pct_mal_{percentage_malicious}%.png'  # Updated line
    plt.savefig(plot_path, dpi=300)
    #plt.show()
    plt.close()


# maybe we do not neeed it since it plot for each edge for each epoch very large numder of plots >> the over_epoch much better
def plot_Identified_vs_Actual_Malicious_Clients(malicious_client_info_per_edge, epoch, save_path, experiment_id, show_plot=False):
    """
    Plots the identified versus actual malicious clients per edge.

    :param malicious_client_info_per_edge: Dictionary with edge IDs as keys and
                                           'identified' and 'actual' sets as values.
    """
    # Extracting counts for plotting
    edges = list(malicious_client_info_per_edge.keys())
    # Extracting counts for plotting
    identified_counts = [len(info['flagged']) for info in malicious_client_info_per_edge.values()]
    confirmed_counts = [len(info['confirmed']) for info in malicious_client_info_per_edge.values()]
    actual_counts = [len(info['actual']) for info in malicious_client_info_per_edge.values()]

    # Positions of groups and bar width
    bar_width = 0.35
    index = np.arange(len(edges))

    # Creating a bar chart
    fig, ax = plt.subplots()
    bar1 = ax.bar(index, identified_counts, bar_width, label='Flagged By Overall Accuracy Detection', color='blue')
    bar2 = ax.bar(index + bar_width * 2, confirmed_counts, bar_width, label='Flagged By Class-Wise Accuracy Detection', color='green')
    bar3 = ax.bar(index + bar_width, actual_counts, bar_width, label='Actual Malicious Clients', color='red')

    ax.set_xlabel('Edge ID')
    ax.set_ylabel('Number of Malicious Clients')
    # Set y-axis to only show integer values
    ax.yaxis.set_major_locator(MaxNLocator(integer=True))

    ax.set_title(f'Identified vs Actual Malicious Clients per Edge - Epoch {epoch}')
    ax.set_xticks(index + bar_width)
    ax.set_xticklabels(edges)
    ax.legend()

    # Save the plot
    filename = f"exp_{experiment_id}_Identified_vs_Actual_Malicious_Clients_per_Edge_epoch_{epoch}.png"
    full_path = os.path.join(save_path, filename)
    plt.savefig(full_path, dpi=300)

    # Optionally show the plot
    if show_plot:
        plt.show()

    # Clear the plot to free memory if not showing
    plt.close()


def plot_Identified_vs_Actual_Malicious_Clients_over_epochs(epoch_edge_malicious_counts, save_path, experiment_id, percentage_malicious):
    epochs = list(epoch_edge_malicious_counts.keys())

    # Convert epochs to integers if they are not already
    epochs = [int(epoch) for epoch in epochs]

    # Determine the number of subplots needed
    num_edges = len(epoch_edge_malicious_counts[epochs[0]])
    fig, axes = plt.subplots(num_edges, 1, figsize=(10, num_edges * 5))  # Adjust the figure size as needed

    if num_edges == 1:  # If there's only one edge, wrap the axes object in a list
        axes = [axes]

    for idx, edge_id in enumerate(epoch_edge_malicious_counts[epochs[0]]):
        identified_counts = [len(epoch_edge_malicious_counts[epoch][edge_id]['flagged']) for epoch in epochs]
        confirmed_counts = [len(epoch_edge_malicious_counts[epoch][edge_id]['confirmed']) for epoch in epochs]
        actual_counts = [len(epoch_edge_malicious_counts[epoch][edge_id]['actual']) for epoch in epochs]

        # Plot on the respective subplot
        ax = axes[idx]
        ax.plot(epochs, identified_counts, label=f'Edge {edge_id} Flagged By Overall Accuracy Detection', color='blue')
        ax.plot(epochs, confirmed_counts, label=f'Edge {edge_id} Flagged By Class-Wise Accuracy Detection', linestyle='-.', color='green')
        ax.plot(epochs, actual_counts, label=f'Edge {edge_id} Actual Malicious Clients', linestyle='--', color='red')

        ax.set_xlabel('Epoch')
        ax.set_ylabel('Number of Malicious Clients')
        ax.set_title(f'Edge {edge_id}')

        # Set both x-axis and y-axis to only show integer values
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))  # Ensure x-axis labels are integers
        ax.yaxis.set_major_locator(MaxNLocator(integer=True))  # Ensure y-axis labels are integers

        ax.legend()

    plt.tight_layout()  # Adjust subplots to fit in the figure area

    # Save the entire figure with all subplots
    filename = f"exp_{experiment_id}_pct_mal_{percentage_malicious}%_Malicious_Clients_Trends_All_Edges.png"
    full_path = os.path.join(save_path, filename)
    plt.savefig(full_path, dpi=300)

    plt.close(fig)  # Close the figure to free memory

def plot_performance_metrics_of_2steps_detection_over_epochs(performance_metrics, save_path, experiment_id, percentage_malicious):
    if not performance_metrics:
        print("No performance metrics data available.")
        return

    # Sorting the epochs which are expected to be integers
    epochs = sorted([int(epoch) for epoch in performance_metrics.keys()])

    # Check if there are any epochs to plot
    if not epochs:
        print("No epochs data available for plotting.")
        return

    # Determine the global min and max values for consistent y-axis scaling
    y_max = max(max(metrics['tpr'], metrics['fpr'], metrics['accuracy'])
                for edge_metrics in performance_metrics.values()
                for metrics in edge_metrics.values())
    y_min = min(min(metrics['tpr'], metrics['fpr'], metrics['accuracy'])
                for edge_metrics in performance_metrics.values()
                for metrics in edge_metrics.values())

    # Use integer for accessing the dictionary
    num_edges = len(performance_metrics[epochs[0]])

    # Increase the height of each subplot for better visibility
    subplot_height = 4  # You can adjust this value as needed
    fig, axes = plt.subplots(num_edges, 1, figsize=(10, num_edges * subplot_height), dpi=300)

    # Adjust for the case of a single subplot
    if num_edges == 1:
        axes = [axes]

    for idx, edge_id in enumerate(sorted(performance_metrics[epochs[0]])):
        ax = axes[idx] if num_edges > 1 else axes
        # Convert to percentages
        tpr = [performance_metrics[epoch][edge_id]['tpr'] * 100 for epoch in epochs]
        fpr = [performance_metrics[epoch][edge_id]['fpr'] * 100 for epoch in epochs]
        accuracy = [performance_metrics[epoch][edge_id]['accuracy'] * 100 for epoch in epochs]

        ax.plot(epochs, tpr, label='True Positive Rate', color='blue', linestyle='-', marker='o')
        ax.plot(epochs, fpr, label='False Positive Rate', color='red', linestyle='--', marker='x')
        ax.plot(epochs, accuracy, label='Accuracy', color='green', linestyle='-.', marker='s')

        ax.set_ylim(0, 100)  # Set y-axis to range from 0% to 100%
        ax.grid(True)  # Add grid lines for better readability
        ax.set_xlabel('Epoch', fontsize=10)  # Adjust font size if necessary
        ax.set_ylabel('Metric Value (%)', fontsize=10)
        ax.set_title(f'Edge {edge_id}', fontsize=12)

        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
        #ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{int(y)}%'))
        # Use PercentFormatter for more granularity on y-axis percentages
        ax.yaxis.set_major_formatter(PercentFormatter())


    # Set a common legend for all subplots
    # Obtain handles and labels from the last `ax` (which has the complete legend)
    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5, 0.02), ncol=3, fontsize=10)

    # Adjust layout to make room for the common legend
    plt.tight_layout(rect=[0, 0.03, 1, 0.93])
    plt.subplots_adjust(bottom=0.1, top=0.9)  # Reduced bottom and top margins

    # Overall title for the entire figure
    plt.suptitle(f'Detection Performance Metrics Across All Edges - Malicious Clients {percentage_malicious}%', fontsize=14, y=0.97)

    # Construct the filename and save the plot
    filename = f"exp_{experiment_id}_pct_mal_{percentage_malicious}%_Performance_Metrics.png"
    full_path = os.path.join(save_path, filename)
    plt.savefig(full_path, bbox_inches='tight', dpi=300)  # Save with tight bounding box
    plt.close(fig)

def write_to_csv(file_name, epoch, edge_id, analysis_results, client_mean_gradients, experiment_id):
    # Construct the directory path
    dir_path = './gradient_analysis/csv_files'

    # Ensure the directory exists
    os.makedirs(dir_path, exist_ok=True)

    # Append the experiment ID to the filename and construct the full file path
    file_name_with_exp = f"exp_{experiment_id}_{file_name}"
    full_file_path = os.path.join(dir_path, file_name_with_exp)

    # Check if the file exists and is non-empty
    file_exists = os.path.isfile(full_file_path) and os.path.getsize(full_file_path) > 0

    # Open the file in append mode or create it if it doesn't exist
    with open(full_file_path, mode='a', newline='') as file:
        writer = csv.writer(file)

        # If the file does not exist or is empty, write the header
        if not file_exists:
            writer.writerow(["Epoch", "Client_ID", "Edge_ID", "Parameter", "Cosine Similarity", "Distance",
                             "Actual Gradient Value"])

        # Write the data rows
        for cid, client_analysis in analysis_results.items():
            for parameter, metrics in client_analysis.items():
                actual_gradient = client_mean_gradients[cid][
                    parameter].tolist() if cid in client_mean_gradients and parameter in client_mean_gradients[
                    cid] else None
                writer.writerow([
                    epoch,
                    cid,
                    edge_id,
                    parameter,
                    metrics['cosine_similarity'],
                    metrics['distance_from_mean'],
                    actual_gradient  # Add the actual gradient value
                ])

def update_plots(edge_id, csv_file_path, save_path,experiment_id):
    # Load the CSV data into a DataFrame
    #df = pd.read_csv(csv_file_path)
    try:
        df = pd.read_csv(csv_file_path, encoding='ISO-8859-1')
    except UnicodeDecodeError:
        try:
            df = pd.read_csv(csv_file_path, encoding='cp1252')
        except UnicodeDecodeError:
            df = pd.read_csv(csv_file_path, encoding='utf-16')

    # Filter the dataframe for this edge
    df_edge = df[df['Edge_ID'] == edge_id]

    # Get a list of unique parameters
    parameters = df_edge['Parameter'].unique()

    # Determine the number of subplot rows needed, one for each parameter
    num_parameters = len(parameters)

    # Create a figure with subplots - two columns for cosine similarity and distance
    fig, axes = plt.subplots(nrows=num_parameters, ncols=2, figsize=(14, 4 * num_parameters))

    # Ensure the save path exists
    os.makedirs(save_path, exist_ok=True)

    # Loop through each parameter and create its plots
    for i, parameter in enumerate(parameters):
        # Filter the dataframe for this parameter
        df_param = df_edge[df_edge['Parameter'] == parameter]

        # Cosine Similarity subplot
        axes[i, 0].set_title(f'Cosine Similarity for {parameter}')
        axes[i, 0].set_xlabel('Epoch')
        axes[i, 0].set_ylabel('Cosine Similarity')

        # Euclidean Distance subplot
        axes[i, 1].set_title(f'Distance for {parameter}')
        axes[i, 1].set_xlabel('Epoch')
        axes[i, 1].set_ylabel('Distance')

        for client_id in df_param['Client_ID'].unique():
            client_data = df_param[df_param['Client_ID'] == client_id]
            axes[i, 0].plot(client_data['Epoch'], client_data['Cosine Similarity'], marker='o', linestyle='-',
                            label=f'Client {client_id}')
            axes[i, 1].plot(client_data['Epoch'], client_data['Distance'], marker='x', linestyle='-',
                            label=f'Client {client_id}')

        # Add legends to the subplots
        axes[i, 0].legend()
        axes[i, 1].legend()

    # Adjust layout to prevent overlap
    fig.tight_layout()

    # Save the figure
    # Save the figure with experiment_id included in the filename
    fig.savefig(f"{save_path}/exp_{experiment_id}_edge_{edge_id}_parameters_over_time.png", dpi=300)

    plt.close(fig)



def plot_each_class_wise_comparisons_separately(edge_to_clients_accuracies, edge_class_accuracies, directory, experiment_id, epoch):
    # Check if the directory exists, and create it if it doesn't
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Iterate over each edge and its data
    for edge_id, clients_accuracies in edge_to_clients_accuracies.items():
        num_classes = len(edge_class_accuracies[edge_id])
        for class_id in range(num_classes):
            plt.figure()

            # Sort client IDs
            sorted_clients = sorted(clients_accuracies.keys())

            # Plot the accuracy for the edge model for this class, converting to percentage
            edge_accuracy = edge_class_accuracies[edge_id].get(class_id, 0) * 100
            plt.axhline(y=edge_accuracy, color='k', linestyle='--', label=f'Edge {edge_id} Model')

            # Plot the accuracy for each client for this class, sorted by client ID, converting to percentage
            for client_id in sorted_clients:
                client_accuracy = clients_accuracies[client_id].get(class_id, 0) * 100
                plt.bar(client_id, client_accuracy, label=f'Client {client_id}')

            plt.xlabel('Client ID')
            plt.ylabel('Accuracy (%)')
            plt.title(f'Edge {edge_id} - Class {class_id} Accuracy Comparison')

            # Set x-axis ticks to sorted client IDs and their labels
            plt.xticks(sorted_clients, labels=[str(id) for id in sorted_clients])

            plt.legend(title="Legend", bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.ylim([0, 100])  # Set the y-axis limit to 100 to represent percentage

            # Save the plot to a file
            file_path = f'{directory}/Exp{experiment_id}_Epoch{epoch}_Edge{edge_id}_class_{class_id}_comparison_separately.png'
            plt.savefig(file_path, bbox_inches='tight', dpi=300)
            plt.close()


# good
def plot_edge_clients_class_comparisons_for_all_classes(edge_to_clients_accuracies, edge_class_accuracies, directory, experiment_id, epoch, num_classes=10):
    # Check if the directory exists, and create it if it doesn't
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Iterate over each edge and its clients
    for edge_id, clients_accuracies in edge_to_clients_accuracies.items():
        # Create a new figure with subplots for each class
        fig, axes = plt.subplots(nrows=num_classes, ncols=1, figsize=(10, 20), sharex=True)
        fig.suptitle(f'Edge {edge_id} Accuracy Comparison Across All Classes', fontsize=16)

        for class_id in range(num_classes):
            ax = axes[class_id] if num_classes > 1 else axes

            # Plot each client's accuracy for the class
            client_ids = list(clients_accuracies.keys())
            # Convert accuracies to percentages
            accuracies_percent = [clients_accuracies[client_id].get(class_id, 0) * 100 for client_id in client_ids]

            # Define bar positions as numerical values
            bar_positions = range(len(client_ids))

            # Define a narrower width for the bars
            bar_width = 0.2  # for slimmer bars, adjust this value as needed

            # Plot bars at the defined positions with the new width
            bars = ax.bar(bar_positions, accuracies_percent, width=bar_width)

            # Set the x-axis ticks and labels
            ax.set_xticks(bar_positions)
            ax.set_xticklabels(client_ids)

            # Annotate each bar with the client ID, placing the label underneath the bar
            for bar, client_id in zip(bars, client_ids):
                ax.annotate(f'{client_id}',
                            xy=(bar.get_x() + bar.get_width() / 2, 0),
                            xytext=(0, -10),  # Offset to move label below the bar
                            textcoords="offset points",
                            ha='center', va='top')

            # Plot edge accuracy as a dashed black line and convert to percentage
            edge_accuracy_percent = edge_class_accuracies[edge_id].get(class_id, 0) * 100
            ax.axhline(y=edge_accuracy_percent, color='k', linestyle='--', label='Edge Model' if class_id == 0 else "")

            ax.set_xlabel('Client ID')
            ax.set_ylabel('Class-Wise Accuracy(%)')  # Update label to indicate percentages
            ax.set_title(f'Class {class_id}')
            ax.set_ylim([0, 100])  # Update limits to 0-100 for percentages
            if class_id == 0:  # Only add the legend to the first subplot
                ax.legend(loc='upper right')

        # Adjust layout and save the figure for the current edge
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        file_path = f'{directory}/Exp_{experiment_id}_Epoch{epoch}_Edge_{edge_id}_class_comparison_all_classes.png'
        plt.savefig(file_path, bbox_inches='tight', dpi=300)
        plt.close(fig)


def plot_class_specific_recall(class_specific_recall, directory, experiment_id, epoch):
    # Check if the directory exists, and create it if it doesn't
    if not os.path.exists(directory):
        os.makedirs(directory)

    num_classes = len(class_specific_recall)
    class_labels = [f'Class {i}' for i in range(num_classes)]

    plt.figure(figsize=(10, 6))
    bar_positions = range(num_classes)
    # Convert recall scores to percentages
    recall_percentages = [score * 100 for score in class_specific_recall]
    plt.bar(bar_positions, recall_percentages, color='dodgerblue')
    plt.xlabel('Class')
    plt.ylabel('Recall Score (%)')  # Update label to indicate percentages
    plt.title('Class Specific Recall')
    plt.xticks(bar_positions, class_labels)
    plt.ylim([0, 100])  # Update limits to 0-100 for percentages

    # Save the plot to a file
    file_path = f'{directory}/Exp{experiment_id}_Epoch{epoch}_class_specific_recall.png'
    plt.savefig(file_path, bbox_inches='tight', dpi=300)
    plt.close()


def plot_discrepancies_separately(discrepancies, poisoned_workers, directory, experiment_id, edge_id, epoch):
    if not os.path.exists(directory):
        os.makedirs(directory)
    # Try to get the number of classes from the first valid entry
    try:
        # Check if the first entry is a dictionary and use it to get the number of classes
        first_entry = next(iter(discrepancies.values()))
        if isinstance(first_entry, dict):
            num_classes = len(first_entry)
        else:
            raise ValueError("Discrepancy data is not in the expected dictionary format.")
    except StopIteration:
        raise ValueError("Discrepancies dictionary is empty.")

    # Assume the structure of discrepancies is {client_id: {class_id: discrepancy_value}}
    # First, determine the number of classes based on the first client's data
    # num_classes = len(next(iter(discrepancies.values())))

    # For each class, we'll create a separate plot
    for class_id in range(num_classes):
        plt.figure(figsize=(10, 6))
        client_ids = sorted(discrepancies.keys())
        client_discrepancies = [discrepancies[client_id].get(class_id, 0) for client_id in client_ids]

        # Create bars and color them based on whether the client is poisoned
        bars = plt.bar(client_ids, client_discrepancies, color=['red' if client_id in poisoned_workers else 'skyblue' for client_id in client_ids])

        plt.xlabel('Client ID')
        plt.ylabel('Discrepancy')
        plt.title(f'Class {class_id} Discrepancies - Edge {edge_id}')
        plt.xticks(client_ids)
        plt.axhline(0, color='k', linewidth=0.8)  # Add a line at zero for reference

        # Save the plot to a file for the current class
        file_path = f'{directory}/Exp{experiment_id}_Epoch{epoch}_Edge{edge_id}_class_{class_id}_discrepancies.png'
        plt.savefig(file_path, bbox_inches='tight', dpi=300)
        plt.close()

# with color of poisoned_workers
def plot_discrepancies_for_all_classes(discrepancies, poisoned_workers, directory, experiment_id, edge_id, epoch):
    # Check if the directory exists, and create it if it doesn't
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Determine the number of classes from the first client's data
    num_classes = len(next(iter(discrepancies.values())))

    # Create a figure with subplots for each class
    fig, axes = plt.subplots(nrows=num_classes, ncols=1, figsize=(10, 20), sharex=True)
    fig.suptitle(f'Class-wise Discrepancies - Edge {edge_id} - Epoch {epoch}', fontsize=16)

    # Prepare client IDs and bar positions
    client_ids = sorted(discrepancies.keys())
    bar_positions = np.arange(len(client_ids))

    # Fixed bar width for consistent spacing
    bar_width = 0.2

    for class_id, ax in enumerate(axes.flatten()):
        # Gather discrepancies for this class from each client
        client_discrepancies = [discrepancies[client_id].get(class_id, 0) for client_id in client_ids]

        # Create bars for discrepancies and set colors
        bars = ax.bar(bar_positions, client_discrepancies, width=bar_width)
        for bar, client_id in zip(bars, client_ids):
            if client_id in poisoned_workers:
                bar.set_color('red')
            else:
                bar.set_color('skyblue')

        # Set x-ticks and labels for each subplot
        ax.set_xticks(bar_positions)
        ax.set_xticklabels(client_ids)

        # Draw a line at zero for reference
        ax.axhline(0, color='k', linestyle='-', linewidth=1)

        # Set labels and title for each subplot
        ax.set_ylabel('Discrepancy')
        ax.set_title(f'Class {class_id}')

    # Adjust layout, save the figure, and close the plot
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    file_path = f'{directory}/Exp{experiment_id}_Epoch{epoch}_Edge{edge_id}_all_classes_discrepancies.png'
    plt.savefig(file_path, bbox_inches='tight', dpi=300)
    plt.close(fig)

###### old plotting taken from run-exp file

def plot_accuracy_per_client(clients, plot_dir, experiment_id):
    for cid, client in enumerate(clients):
        epochs = sorted(client.accuracy_per_epoch.keys())
        accuracies = [client.accuracy_per_epoch[e] for e in epochs]
        plt.plot(epochs, accuracies, label=f'Client {cid}')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.legend()
    plt.grid(True)
    plt.savefig(f'{plot_dir}/accuracy_per_client_Exp_{experiment_id}.png', dpi=300)  # Updated line
    plt.clf()  # clear the figure for the next plot



def plot_combined_accuracy(clients, plot_dir, experiment_id):
    combined_accuracies = defaultdict(list)
    for client in clients:
        for epoch, acc in client.accuracy_per_epoch.items():
            combined_accuracies[epoch].append(acc)
    avg_accuracies = {epoch: sum(accs) / len(accs) for epoch, accs in combined_accuracies.items()}
    epochs = sorted(avg_accuracies.keys())
    accuracies = [avg_accuracies[e] for e in epochs]
    plt.plot(epochs, accuracies)
    plt.xlabel('Epoch')
    plt.ylabel('Average Accuracy')
    plt.grid(True)
    plt.savefig(f'{plot_dir}/combined_accuracy_Exp_{experiment_id}.png')  # Updated line
    plt.clf()  # clear the figure for the next plot




def plot_client_performances(client_performances, overall_accuracy):
    """
    Generate a bar chart to visualize client performances and overall accuracy.

    :param client_performances: Dictionary mapping client IDs to their accuracy.
    :param overall_accuracy: The overall accuracy of the model.
    """

    # Extract data
    client_ids = list(client_performances.keys())
    accuracies = list(client_performances.values())

    # Plot
    plt.figure(figsize=(10, 6))
    bars = plt.bar(client_ids, accuracies, color='blue', alpha=0.7, label="Client's Accuracy")
    plt.axhline(y=overall_accuracy, color='r', linestyle='-', label='Overall Accuracy')
    plt.xlabel('Client ID')
    plt.ylabel('Accuracy (%)')
    plt.title('Client Performances vs. Overall Accuracy')
    plt.xticks(client_ids)  # Set x-axis ticks to be client IDs
    plt.legend()

    # Annotate the bars with their accuracy values
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, yval + 0.5, round(yval, 2), ha='center', va='bottom', color='black')

    plt.tight_layout()
    plt.show()
