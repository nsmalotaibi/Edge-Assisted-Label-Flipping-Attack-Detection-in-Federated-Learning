import random

def default_no_change(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    return targets

def replacement_method_edited(targets):
    """
    Replace class labels based on a replacement method

    :param targets: Target class IDs
    :type targets: torch.Tensor
    :return: New class IDs
    :rtype: torch.Tensor
    """
    # TODO: Implement the replacement method based on your requirements
    # Example: Replace all 0s with 9s
    targets[targets == 0] = 9
    return targets


def replace_half_of_1_with_3(targets, target_set):
    """
    Flips 50% of the instances of label 1 to label 3.

    :param targets: Target class IDs
    :type targets: list
    :return: new class IDs with 50% of label 1 flipped to label 3
    """
    indices_of_1 = [idx for idx, value in enumerate(targets) if value == 1]
    indices_to_flip = random.sample(indices_of_1, len(indices_of_1) // 2)

    for idx in indices_to_flip:
        targets[idx] = 3

    return targets

def replace_7_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 7:
            targets[idx] = 9

    return targets

def replace_0_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 0:
            targets[idx] = 9

    return targets

def replace_0_with_6(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 0:
            targets[idx] = 6

    return targets

def replace_4_with_6(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 4:
            targets[idx] = 6

    return targets

def replace_1_with_3(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 1:
            targets[idx] = 3

    return targets

def replace_1_with_0(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 1:
            targets[idx] = 0

    return targets

def replace_2_with_3(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 2:
            targets[idx] = 3

    return targets

def replace_2_with_7(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 2:
            targets[idx] = 7

    return targets

def replace_3_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 3:
            targets[idx] = 9

    return targets

def replace_3_with_7(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 3:
            targets[idx] = 7

    return targets

def replace_4_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 4:
            targets[idx] = 9

    return targets

def replace_4_with_1(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 4:
            targets[idx] = 1

    return targets

def replace_5_with_3(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 5:
            targets[idx] = 3

    return targets

def replace_1_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 1:
            targets[idx] = 9

    return targets

def replace_0_with_2(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 0:
            targets[idx] = 2

    return targets

def replace_5_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 5:
            targets[idx] = 9

    return targets

def replace_5_with_7(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 5:
            targets[idx] = 7

    return targets

def replace_6_with_3(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 6:
            targets[idx] = 3

    return targets

def replace_6_with_0(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 6:
            targets[idx] = 0

    return targets

def replace_6_with_7(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 6:
            targets[idx] = 7

    return targets

def replace_7_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 7:
            targets[idx] = 9

    return targets

def replace_7_with_1(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 7:
            targets[idx] = 1

    return targets

def replace_8_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 8:
            targets[idx] = 9

    return targets

def replace_8_with_6(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 8:
            targets[idx] = 6

    return targets

def replace_9_with_3(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 9:
            targets[idx] = 3

    return targets

def replace_9_with_7(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 9:
            targets[idx] = 7

    return targets

def replace_0_with_9_1_with_3(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 0:
            targets[idx] = 9
        elif targets[idx] == 1:
            targets[idx] = 3

    return targets

def replace_0_with_6_1_with_0(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 0:
            targets[idx] = 6
        elif targets[idx] == 1:
            targets[idx] = 0

    return targets

def replace_1_with_3_3_with_1(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 1:
            targets[idx] = 3
        elif targets[idx] == 3:
            targets[idx] = 1

    return targets

def replace_2_with_3_3_with_9(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 2:
            targets[idx] = 3
        elif targets[idx] == 3:
            targets[idx] = 9

    return targets

def replace_2_with_7_3_with_7(targets, target_set):
    """
    :param targets: Target class IDs
    :type targets: list
    :param target_set: Set of class IDs possible
    :type target_set: list
    :return: new class IDs
    """
    for idx in range(len(targets)):
        if targets[idx] == 2:
            targets[idx] = 7
        elif targets[idx] == 3:
            targets[idx] = 7

    return targets
