
import os
import time
import torch
import psutil
import GPUtil


def initialize_total_sums():
    return {
        "execution_time": 0,
        "cpu_usage_difference": 0,  # Fixed typo from 'cpu_usa'
        "delta_alloc": 0,
        "delta_cached": 0,
        "memory_usage_difference": 0,
        "communication_time": 0,
        "processing_time": 0,
        "detection_latency": 0,
    }


def initialize_total_counts():
    return {
        "execution_time": 0,
        "cpu_usage_difference": 0,
        "delta_alloc": 0,
        "delta_cached": 0,
        "memory_usage_difference": 0,
        "communication_time": 0,
        "processing_time": 0,
        "detection_latency": 0,
    }


def measure_cpu_resources():
    """ Measure CPU and system memory usage. """
    cpu_percent = psutil.cpu_percent(interval=1)
    memory_usage = psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)  # Convert bytes to MB
    return cpu_percent, memory_usage


def measure_gpu_resources():
    """ Measure GPU load and memory usage if a GPU is available. """
    gpus = GPUtil.getGPUs()
    gpu_load = gpus[0].load if gpus else 0  # Handle the case of no GPUs found
    memory_allocated = torch.cuda.memory_allocated(0) if torch.cuda.is_available() else 0
    memory_reserved = torch.cuda.memory_reserved(0) if torch.cuda.is_available() else 0
    return gpu_load, memory_allocated, memory_reserved


def start_processing():
    """ Initialize resource measurements before processing clients. """
    cpu_percent_before, mem_before = measure_cpu_resources()
    gpu_before, memory_allocated_before, memory_cached_before = (0, 0, 0)

    if torch.cuda.is_available():
        gpu_before, memory_allocated_before, memory_cached_before = measure_gpu_resources()

    exc_start_time = time.time()  # Execution start time
    processing_start_time = time.time()  # Processing start time

    # Return all measurements
    return {
        'cpu_percent_before': cpu_percent_before,
        'mem_before': mem_before,
        'gpu_before': gpu_before,
        'memory_allocated_before': memory_allocated_before,
        'memory_cached_before': memory_cached_before,
        'exc_start_time': exc_start_time,
        'processing_start_time': processing_start_time
    }




def calculate_time_metrics(edge, selected_cid, resources_before):
    detection_time = time.time()
    send_time = edge.client_send_times[selected_cid]
    receive_time = edge.client_receive_times[selected_cid]
    communication_time = receive_time - send_time
    processing_time = detection_time - resources_before['processing_start_time']
    detection_latency = detection_time - send_time
    return communication_time, processing_time, detection_latency


def gather_resource_usage(resources_before, resources_after):
    return {
        'execution_time': resources_after['execution_time'],
        'cpu_usage_difference': resources_after['cpu_usage_difference'],
        'gpu_usage_difference': resources_after['gpu_usage_difference'],
        'memory_usage_difference': resources_after['memory_usage_difference'],
        'delta_alloc': resources_after['delta_alloc'],
        'delta_cached': resources_after['delta_cached']
    }


def update_epoch_edge_efficiency_metrics(metrics, epoch, edge, resource_usage, communication_time, processing_time,
                             detection_latency):
    if epoch not in metrics['detection_efficiency_metrics']:
        metrics['detection_efficiency_metrics'][epoch] = {}
    if edge.get_edge_id() not in metrics['detection_efficiency_metrics'][epoch]:
        metrics['detection_efficiency_metrics'][epoch][edge.get_edge_id()] = []

    metrics['detection_efficiency_metrics'][epoch][edge.get_edge_id()].append({
        "execution_time": resource_usage['execution_time'],
        "cpu_usage_difference": resource_usage['cpu_usage_difference'],
        "gpu_usage_difference": resource_usage['gpu_usage_difference'],
        "delta_alloc": resource_usage['delta_alloc'],
        "delta_cached": resource_usage['delta_cached'],
        "memory_usage_difference": resource_usage['memory_usage_difference'],
        "communication_time": communication_time,
        "processing_time": processing_time,
        "detection_latency": detection_latency
    })

def log_updated_epoch_edge_efficiency_metrics(file_path, epoch, edge, resource_usage, gpu_before, gpu_after, communication_time,
                            processing_time, detection_latency):
    """Logs detection resources and metrics to a specified file."""
    with open(file_path, "a") as file:
        file.write(f"Edge Detection Resources at Epoch: {epoch} For Edge: {edge.get_edge_id()}\n")
        file.write(f"Total Detection Execution Time: {resource_usage['execution_time']} seconds\n")
        file.write(f"CPU Usage Difference: {resource_usage['cpu_usage_difference']}%\n")
        file.write(
            f"GPU Usage Before: {gpu_before}%, After: {gpu_after}%, Difference: {resource_usage['gpu_usage_difference']}%\n")
        file.write(f"Change in Allocated Memory: {resource_usage['delta_alloc']} MB\n")
        file.write(f"Change in Cached Memory: {resource_usage['delta_cached']} MB\n")
        file.write(f"Memory Usage Difference: {resource_usage['memory_usage_difference']} MB\n")
        file.write(f"Communication Time: {communication_time} seconds\n")
        file.write(f"Processing Time: {processing_time} seconds\n")
        file.write(f"Total Detection Latency: {detection_latency} seconds\n")
        file.write("-" * 50 + "\n")





def efficiency_metrics_for_epoch(epoch, detection_efficiency_metrics=None):
    if detection_efficiency_metrics is None:
        detection_efficiency_metrics = {}

    metrics_sums = {
        "execution_time": 0,
        "cpu_usage_difference": 0,
        "delta_alloc": 0,
        "delta_cached": 0,
        "memory_usage_difference": 0,
        "communication_time": 0,  # New
        "processing_time": 0,  # New
        "detection_latency": 0,  # New
    }
    num_edges = 0

    # Sum up all metrics for each edge in the given epoch
    if epoch in detection_efficiency_metrics:
        for edge_id, metrics_list in detection_efficiency_metrics[epoch].items():
            for metrics in metrics_list:
                metrics_sums["execution_time"] += metrics["execution_time"]
                metrics_sums["cpu_usage_difference"] += metrics["cpu_usage_difference"]
                metrics_sums["delta_alloc"] += metrics["delta_alloc"]
                metrics_sums["delta_cached"] += metrics["delta_cached"]
                metrics_sums["memory_usage_difference"] += metrics["memory_usage_difference"]
                # Sum the new metrics
                metrics_sums["communication_time"] += metrics.get("communication_time", 0)
                metrics_sums["processing_time"] += metrics.get("processing_time", 0)
                metrics_sums["detection_latency"] += metrics.get("detection_latency", 0)
                num_edges += 1

    # Calculate the average for each metric
    average_metrics = {metric: metrics_sums[metric] / num_edges if num_edges > 0 else 0
                       for metric in metrics_sums}

    # Return both the sums and averages
    return metrics_sums, average_metrics


# def end_processing(cpu_percent_before, gpu_before, memory_allocated_before, memory_cached_before, mem_before, processing_start_time, exc_start_time):
#     """ Finalize resource measurements after processing clients. """
#     exc_end_time = time.time()
#     execution_time = exc_end_time - exc_start_time  # Time since the start of execution
#     cpu_percent_after = psutil.cpu_percent(interval=1)  # Current CPU usage percentage
#     gpu_after = GPUtil.getGPUs()[0].load if torch.cuda.is_available() and GPUtil.getGPUs() else 0  # Current GPU load
#     memory_allocated_after = torch.cuda.memory_allocated(0) if torch.cuda.is_available() else 0  # Current GPU allocated memory
#     memory_cached_after = torch.cuda.memory_reserved(0) if torch.cuda.is_available() else 0  # Current GPU cached memory
#     mem_after = psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)  # Current process memory usage in MB, # Convert bytes to MB
#
#     # Calculate differences
#     resources = {
#         'execution_time': execution_time,
#         'cpu_usage_difference': cpu_percent_after - cpu_percent_before,
#         'gpu_usage_difference': gpu_after - gpu_before if torch.cuda.is_available() else 0,
#         'delta_alloc': (memory_allocated_after - memory_allocated_before) / (1024 ** 2),  # Convert to MB
#         'delta_cached': (memory_cached_after - memory_cached_before) / (1024 ** 2),  # Convert to MB
#         'memory_usage_difference': mem_after - mem_before
#     }
#     return resources


def end_processing(start_resources):
    """ Finalize resource measurements after processing clients. """
    cpu_percent_after, mem_after = measure_cpu_resources()
    gpu_after, memory_allocated_after, memory_cached_after = (0, 0, 0)
    if torch.cuda.is_available():
        gpu_after, memory_allocated_after, memory_cached_after = measure_gpu_resources()
    return {
        'execution_time': time.time() - start_resources['exc_start_time'],
        'cpu_usage_difference': cpu_percent_after - start_resources['cpu_percent_before'],
        'gpu_usage_difference': gpu_after - start_resources['gpu_before'],
        'delta_alloc': (memory_allocated_after - start_resources['memory_allocated_before']) / (1024 ** 2),
        'delta_cached': (memory_cached_after - start_resources['memory_cached_before']) / (1024 ** 2),
        'memory_usage_difference': (mem_after - start_resources['mem_before']),
        'processing_time': time.time() - start_resources['processing_start_time'],
        'gpu_after': gpu_after  # Make sure to return this
    }


def log_epoch_efficiency_metrics(file_path, metrics):
    """
    Logs efficiency metrics for each epoch into a file.

    :param file_path: Path to the file where the metrics will be logged.
    :param metrics: Dictionary containing efficiency metrics.
    """
    with open(file_path, "a") as file:
        # Start the logging session for all epochs
        file.write("\nEfficiency Metrics Summary for All Epochs:\n")
        file.write("-" * 100 + "\n")

        # Iterate through each epoch
        for epoch in sorted(metrics['detection_efficiency_metrics'].keys()):
            metrics_sums, average_metrics = efficiency_metrics_for_epoch(epoch, metrics['detection_efficiency_metrics'])

            # Update totals and counts
            for metric in metrics_sums:
                metrics['total_sums'][metric] += metrics_sums[metric]
                metrics['total_counts'][metric] += 1

            # Log metrics summary for the current epoch
            file.write(f"Epoch {epoch} Metrics Summary:\n")
            file.write("-" * 50 + "\n")
            for metric, total in metrics_sums.items():
                file.write(f"{metric} Total: {total}\n")

            file.write("\nAverage Metrics:\n")
            for metric, average in average_metrics.items():
                file.write(f"{metric} Average: {average}\n")

            file.write("-" * 50 + "\n")  # Separator between epochs

        # After all epochs are processed, log overall averages
        overall_averages = {
            metric: metrics['total_sums'][metric] / metrics['total_counts'][metric] if metrics['total_counts'][
                                                                                           metric] > 0 else 0
            for metric in metrics['total_sums']
        }
        file.write("\nOverall Averages Across All Epochs:\n")
        file.write("-" * 50 + "\n")
        for metric, average in overall_averages.items():
            file.write(f"{metric} Average: {average:.4f}\n")
        file.write("-" * 50 + "\n")
        file.write("End of Overall Averages\n")
