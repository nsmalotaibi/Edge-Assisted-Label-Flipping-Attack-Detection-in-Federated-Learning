import torch
from torch.utils.data import DataLoader
from .label_replacement import apply_class_label_replacement
from .client_utils import log_client_data_statistics


def poison_data(logger, distributed_dataset, num_workers, poisoned_worker_ids, replacement_method):
    """
    Poison worker data

    :param logger: logger
    :type logger: loguru.logger
    :param distributed_dataset: Distributed dataset
    :type distributed_dataset: list(tuple)
    :param num_workers: Number of workers overall
    :type num_workers: int
    :param poisoned_worker_ids: IDs poisoned workers
    :type poisoned_worker_ids: list(int)
    :param replacement_method: Replacement methods to use to replace
    :type replacement_method: list(method)
    """
    # TODO: Add support for multiple replacement methods?
    poisoned_dataset = []

    class_labels = list(set(distributed_dataset[0][1]))
    print("class_labels are", class_labels)

    logger.warning("Poisoning data for workers: {}".format(str(poisoned_worker_ids)))

    for worker_idx in range(num_workers):
        if worker_idx in poisoned_worker_ids:
            poisoned_dataset.append(apply_class_label_replacement(distributed_dataset[worker_idx][0], distributed_dataset[worker_idx][1], replacement_method))

        else:
            poisoned_dataset.append(distributed_dataset[worker_idx])


    log_client_data_statistics(logger, class_labels, poisoned_dataset)

    return poisoned_dataset


def poison_data_new(logger, data_loaders, num_workers, poisoned_worker_ids, replacement_method):
    """
    Poison worker data

    :param logger: logger
    :type logger: loguru.logger
    :param data_loaders: List of DataLoader objects
    :type data_loaders: list(DataLoader)
    :param num_workers: Number of workers overall
    :type num_workers: int
    :param poisoned_worker_ids: IDs poisoned workers
    :type poisoned_worker_ids: list(int)
    :param replacement_method: Replacement methods to use to replace
    :type replacement_method: list(method)
    """
    poisoned_data_loaders = []

    logger.info("Poisoning data for workers: {}".format(str(poisoned_worker_ids)))

    for worker_idx in range(num_workers):
        if worker_idx in poisoned_worker_ids:
            poisoned_data_loaders.append(
                apply_class_label_replacement_new(data_loaders[worker_idx], replacement_method))
        else:
            poisoned_data_loaders.append(data_loaders[worker_idx])

    return poisoned_data_loaders


def apply_class_label_replacement_new(data_loader, replacement_method):
    data_list = []
    target_list = []

    for data, target in data_loader:
        poisoned_target = replacement_method(target, set(target))
        data_list.append(data)
        target_list.append(poisoned_target)

    poisoned_data = torch.cat(data_list)
    poisoned_target = torch.cat(target_list)

    poisoned_dataset = list(zip(poisoned_data, poisoned_target))
    return DataLoader(poisoned_dataset, batch_size=data_loader.batch_size, shuffle=True)
