# Interface between the dataset and client
from federated_learning.datasets.splitting import get_dataset


def get_dataloaders(args):
    """
    :param args:
    :return: A list of trainloaders, a list of testloaders, a concatenated trainloader and a concatenated testloader
    """
    if args.dataset in ['mnist', 'cifar10', 'fashion_mnist', 'cifar100']:
        train_loaders, test_loaders, validation_loader, v_test_loader = get_dataset(dataset_root='data',
                                                                                       dataset=args.dataset,
                                                                                       args = args)
    else:
        raise ValueError("This dataset is not implemented yet")
    return train_loaders, test_loaders, validation_loader, v_test_loader