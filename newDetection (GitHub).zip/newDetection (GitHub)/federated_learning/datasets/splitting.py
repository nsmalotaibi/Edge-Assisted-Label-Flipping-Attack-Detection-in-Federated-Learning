"""
download the required dataset, split the data among the clients, and generate DataLoader for training
"""
import os
import torch
import torchvision
import numpy as np
from sklearn.model_selection import train_test_split
import torch.backends.cudnn as cudnn
cudnn.banchmark = True

import torchvision.transforms as transforms
from torchvision import datasets
from torch.utils.data import DataLoader, Dataset, Subset, SubsetRandomSampler


class DatasetSplit(Dataset):

    def __init__(self, dataset, idxs):
        super(DatasetSplit, self).__init__()
        self.dataset = dataset
        self.idxs = idxs

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, target = self.dataset[self.idxs[item]]
        return image, target



def get_labels(dataset):
    if isinstance(dataset, torchvision.datasets.CIFAR10) or \
       isinstance(dataset, torchvision.datasets.CIFAR100) or \
       isinstance(dataset, torchvision.datasets.MNIST) or \
       isinstance(dataset, torchvision.datasets.FashionMNIST):
        return dataset.targets
    else:
        raise ValueError(f"Unsupported dataset type: {type(dataset)}")


def gen_ran_sum(_sum, num_users):
    base = 100*np.ones(num_users, dtype=np.int32)
    _sum = _sum - 100*num_users
    p = np.random.dirichlet(np.ones(num_users), size=1)
    print(p.sum())
    p = p[0]
    size_users = np.random.multinomial(_sum, p, size=1)[0]
    size_users = size_users + base
    print(size_users.sum())
    return size_users


def get_mean_and_std(dataset):
    """
    compute the mean and std value of dataset
    """
    dataloader = DataLoader(dataset, batch_size = 1, shuffle = True, num_workers = 2)
    mean = torch.zeros(3)
    std = torch.zeros(3)
    print("=>compute mean and std")
    for inputs, targets in dataloader:
        for i in range(3):
            mean[i] += inputs[:,i,:,:].mean()
            std[i] += inputs[:,i,:,:].std()
    mean.div_(len(dataset))
    std.div_(len(dataset))
    return mean, std

# 1 when iid=1 Each client has 10 ALL unique labels
def iid_esize_split(dataset, args, kwargs, is_shuffle = True):
    """
    split the dataset to users
    Return:
        dict of the data_loaders
    """
    sum_samples = len(dataset)
    num_samples_per_client = int(sum_samples / args.num_clients)
    # change from dict to list
    data_loaders = [0] * args.num_clients
    dict_users, all_idxs = {}, [i for i in range(len(dataset))]

    # Loop over the number of clients
    for i in range(args.num_clients):
        # Randomly select `num_samples_per_client` indices from `all_idxs` without replacement
        dict_users[i] = np.random.choice(all_idxs, num_samples_per_client, replace = False)
        #dict_users[i] = dict_users[i].astype(int)
        #dict_users[i] = set(dict_users[i])
        # Remove the selected indices from `all_idxs` to ensure no overlap between clients
        all_idxs = list(set(all_idxs) - set(dict_users[i]))

        # Create a DataLoader for the current client using the selected indices
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                                     batch_size=args.batch_size,
                                     shuffle=is_shuffle, **kwargs)

    return data_loaders

# 2 when iid = -1
# The random sampling in both functions ensures that the data is independently and identically distributed (IID) among clients.
# But the first function gives each client an equal-sized subset, while the second gives potentially unequal-sized subsets.
def iid_nesize_split(dataset, args, kwargs, is_shuffle = True):
    sum_samples = len(dataset)
    num_samples_per_client = gen_ran_sum(sum_samples, args.num_clients)
    # change from dict to list
    data_loaders = [0] * args.num_clients
    dict_users, all_idxs = {}, [i for i in range(len(dataset))]
    for (i, num_samples_client) in enumerate(num_samples_per_client):
        dict_users[i] = np.random.choice(all_idxs, num_samples_client, replace = False)
        #dict_users[i] = dict_users[i].astype(int)
        #dict_users[i] = set(dict_users[i])
        all_idxs = list(set(all_idxs) - set(dict_users[i]))
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                                    batch_size = args.batch_size,
                                    shuffle = is_shuffle, **kwargs)

    return data_loaders

# 3 when iid=0 non-IID data partition [2], referred to as simple NIID where each client owns samples of two classes
# and the clients are randomly assigned to each edge server,
def niid_esize_split(dataset, args, kwargs, is_shuffle = True):
    data_loaders = [0] * args.num_clients
    # each client has only two classes of the network
    num_shards = 2* args.num_clients
    # the number of images in one shard
    num_imgs = int(len(dataset) / num_shards)
    idx_shard = [i for i in range(num_shards)]
    dict_users = {i: np.array([]) for i in range(args.num_clients)}
    idxs = np.arange(num_shards * num_imgs)
    # is_shuffle is used to differentiate between train and test
    #if is_shuffle:
        #labels = dataset.train_labels
    #else:
        #labels = dataset.test_labels
    #labels = dataset.targets
    #labels = dataset.dataset.targets[dataset.indices]
    if isinstance(dataset, Subset):
        labels = dataset.dataset.targets[dataset.indices]
    else:
        labels = dataset.targets

    idxs_labels = np.vstack((idxs, labels))
    idxs_labels = idxs_labels[:, idxs_labels[1,:].argsort()]
    # sort the data according to their label
    idxs = idxs_labels[0,:]
    idxs = idxs.astype(int)

    #divide and assign
    for i in range(args.num_clients):
        rand_set = set(np.random.choice(idx_shard, 2, replace= False))
        idx_shard = list(set(idx_shard) - rand_set)
        for rand in rand_set:
            dict_users[i] = np.concatenate((dict_users[i], idxs[rand * num_imgs: (rand + 1) * num_imgs]), axis=0)
            dict_users[i] = dict_users[i].astype(int)
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                                    batch_size = args.batch_size,
                                    shuffle = is_shuffle, **kwargs)
    return data_loaders

# 4 when iid= and edgeiid =
def niid_esize_split_train(dataset, args, kwargs, is_shuffle = True):
    data_loaders = [0]* args.num_clients
    num_shards = args.classes_per_client * args.num_clients
    num_imgs = int(len(dataset) / num_shards)
    idx_shard = [i for i in range(num_shards)]
    dict_users = {i: np.array([]) for i in range(args.num_clients)}
    idxs = np.arange(num_shards * num_imgs)
#     no need to judge train ans test here
    labels = dataset.train_labels
    idxs_labels = np.vstack((idxs, labels))
    idxs_labels = idxs_labels[:, idxs_labels[1,:].argsort()]
    idxs = idxs_labels[0,:]
    idxs = idxs.astype(int)
#     divide and assign
#     and record the split patter
    split_pattern = {i: [] for i in range(args.num_clients)}
    for i in range(args.num_clients):
        rand_set = np.random.choice(idx_shard, 2, replace= False)
        split_pattern[i].append(rand_set)
        idx_shard = list(set(idx_shard) - set(rand_set))
        for rand in rand_set:
            dict_users[i] = np.concatenate((dict_users[i], idxs[rand * num_imgs: (rand + 1) * num_imgs]), axis=0)
            dict_users[i] = dict_users[i].astype(int)
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                                     batch_size=args.batch_size,
                                     shuffle=is_shuffle,
                                     **kwargs
                                     )
    return data_loaders, split_pattern

# 5 when iid= and edgeiid =
def niid_esize_split_test(dataset, args, kwargs, split_pattern,  is_shuffle = False ):
    data_loaders = [0] * args.num_clients
    num_shards = args.classes_per_client * args.num_clients
    num_imgs = int(len(dataset) / num_shards)
    idx_shard = [i for i in range(num_shards)]
    dict_users = {i: np.array([]) for i in range(args.num_clients)}
    idxs = np.arange(num_shards * num_imgs)
    #     no need to judge train ans test here
    labels = dataset.test_labels
    idxs_labels = np.vstack((idxs, labels))
    idxs_labels = idxs_labels[:, idxs_labels[1, :].argsort()]
    idxs = idxs_labels[0, :]
    idxs = idxs.astype(int)
#     divide and assign
    for i in range(args.num_clients):
        rand_set = split_pattern[i][0]
        idx_shard = list(set(idx_shard) - set(rand_set))
        for rand in rand_set:
            dict_users[i] = np.concatenate((dict_users[i], idxs[rand * num_imgs: (rand + 1) * num_imgs]), axis=0)
            dict_users[i] = dict_users[i].astype(int)
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                                     batch_size=args.batch_size,
                                     shuffle=is_shuffle,
                                     **kwargs
                                     )
    return data_loaders, None

# 6 when iid= and edgeiid =
def niid_esize_split_train_large(dataset, args, kwargs, is_shuffle = True):
    data_loaders = [0]* args.num_clients
    num_shards = args.classes_per_client * args.num_clients
    num_imgs = int(len(dataset) / num_shards)
    idx_shard = [i for i in range(num_shards)]
    dict_users = {i: np.array([]) for i in range(args.num_clients)}
    idxs = np.arange(num_shards * num_imgs)
    labels = dataset.train_labels
    idxs_labels = np.vstack((idxs, labels))
    idxs_labels = idxs_labels[:, idxs_labels[1,:].argsort()]
    idxs = idxs_labels[0,:]
    idxs = idxs.astype(int)

    split_pattern = {i: [] for i in range(args.num_clients)}
    for i in range(args.num_clients):
        rand_set = np.random.choice(idx_shard, 2, replace= False)
        # split_pattern[i].append(rand_set)
        idx_shard = list(set(idx_shard) - set(rand_set))
        for rand in rand_set:
            dict_users[i] = np.concatenate((dict_users[i], idxs[rand * num_imgs: (rand + 1) * num_imgs]), axis=0)
            dict_users[i] = dict_users[i].astype(int)
            # store the label
            split_pattern[i].append(dataset.__getitem__(idxs[rand * num_imgs])[1])
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                                     batch_size=args.batch_size,
                                     shuffle=is_shuffle,
                                     **kwargs
                                     )
    return data_loaders, split_pattern

# 7 when iid= and edgeiid =
# i guess Edge-NIID: Assign each client samples of one class, and assign each edge 10 clients
# with a total of 5 classes of labels. The datasets among edges are non-IID.
def niid_esize_split_test_large(dataset, args, kwargs, split_pattern, is_shuffle = False ):
    """
    :param dataset: test dataset
    :param args:
    :param kwargs:
    :param split_pattern: split pattern from trainloaders
    :param test_size: length of testloader of each client
    :param is_shuffle: False for testloader
    :return:
    """
    data_loaders = [0] * args.num_clients
    # for mnist and cifar 10, only 10 classes
    num_shards = 10
    num_imgs = int (len(dataset) / num_shards)
    idx_shard = [i for i in range(num_shards)]
    dict_users = {i: np.array([]) for i in range(args.num_clients)}
    idxs = np.arange(len(dataset))
    #     no need to judge train ans test here
    labels = dataset.test_labels
    idxs_labels = np.vstack((idxs, labels))
    idxs_labels = idxs_labels[:, idxs_labels[1, :].argsort()]
    idxs = idxs_labels[0, :]
    idxs = idxs.astype(int)
#     divide and assign
    for i in range(args.num_clients):
        rand_set = split_pattern[i]
        # idx_shard = list(set(idx_shard) - set(rand_set))
        for rand in rand_set:
            dict_users[i] = np.concatenate((dict_users[i], idxs[rand * num_imgs: (rand + 1) * num_imgs]), axis=0)
            dict_users[i] = dict_users[i].astype(int)
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                                     batch_size=args.batch_size,
                                     shuffle=is_shuffle,
                                     **kwargs
                                     )
    return data_loaders, None

# 8 when iid=-2 edgeiid = 1 Edge-IID: Assign each client samples of one class,
# and assign each edge 10 clients with different classes.
# The datasets among edges are IID.
def niid_esize_split_oneclass(dataset, args, kwargs, is_shuffle = True):
    data_loaders = [0] * args.num_clients
    #one class perclients
    #any requirements on the number of clients?
    num_shards = args.num_clients
    num_imgs = int(len(dataset) / num_shards)
    idx_shard = [i for i in range(num_shards)]
    dict_users = {i: np.array([]) for i in range(args.num_clients)}
    idxs = np.arange(num_shards * num_imgs)
    # if is_shuffle:
    #     labels = dataset.train_labels # was train_labels
    # else:
    #     labels = dataset.test_labels  # was test_labels
    #labels = dataset.targets
    # to fix the issue of targets after use subset instead of train dataset
    if isinstance(dataset, Subset):
        labels = dataset.dataset.targets[dataset.indices]
    else:
        labels = dataset.targets

    idxs_labels = np.vstack((idxs, labels))
    idxs_labels = idxs_labels[:, idxs_labels[1,:].argsort()]
    idxs = idxs_labels[0,:]
    idxs = idxs.astype(int)

    #divide and assign
    for i in range(args.num_clients):
        rand_set = set(np.random.choice(idx_shard, 1, replace = False))
        idx_shard = list(set(idx_shard) - rand_set)
        for rand in rand_set:
            dict_users[i] = np.concatenate((dict_users[i], idxs[rand * num_imgs: (rand+1)*num_imgs]), axis = 0)
            dict_users[i] = dict_users[i].astype(int)
        data_loaders[i] = DataLoader(DatasetSplit(dataset, dict_users[i]),
                            batch_size = args.batch_size,
                            shuffle = is_shuffle, **kwargs)
    return data_loaders


def split_data(dataset, args, kwargs, is_shuffle = True):
    """
    return dataloaders
    """
    if args.iid == 1:
        data_loaders = iid_esize_split(dataset, args, kwargs, is_shuffle)
    elif args.iid == 0:
        data_loaders = niid_esize_split(dataset, args, kwargs, is_shuffle)
    elif args.iid == -1:
        data_loaders = iid_nesize_split(dataset, args, kwargs, is_shuffle)
    elif args.iid == -2:
        data_loaders = niid_esize_split_oneclass(dataset, args, kwargs, is_shuffle)
    else :
        raise ValueError('Data Distribution pattern `{}` not implemented '.format(args.iid))
    return data_loaders

def get_dataset(dataset_root, dataset, args):
    trains, train_loaders, tests, test_loaders = {}, {}, {}, {}
    if dataset == 'mnist':
        train_loaders, test_loaders, validation_loader, v_test_loader = get_mnist(dataset_root, args)
    elif dataset == 'cifar10':
        train_loaders, test_loaders, validation_loader, v_test_loader = get_cifar10(dataset_root, args)
    elif dataset == 'fashion_mnist':
        train_loaders, test_loaders, validation_loader, v_test_loader = get_fashion_mnist(dataset_root, args)
    elif dataset == 'femnist':
        raise ValueError('CODING ERROR: FEMNIST dataset should not use this file')
    else:
        raise ValueError('Dataset `{}` not found'.format(dataset))
    return train_loaders, test_loaders, validation_loader, v_test_loader


def get_mnist(dataset_root, args):
    args.get_logger().debug("Loading MNIST")
    is_cuda = args.cuda
    kwargs = {'num_workers': 1, 'pin_memory': True} if is_cuda else {}
    transform=transforms.Compose([
                            transforms.ToTensor(),
                            transforms.Normalize((0.1307,), (0.3081,)),
                        ])
    train = datasets.MNIST(os.path.join(dataset_root, 'mnist'), train = True,
                            download = True, transform = transform)
    test =  datasets.MNIST(os.path.join(dataset_root, 'mnist'), train = False,
                            download = True, transform = transform)

    #the actual batch_size may need to change.... Depend on the actual gradient...
    #originally written to get the gradient of the whole dataset
    #but now it seems to be able to improve speed of getting accuracy of virtual sequence
    # Splitting train_dataset into actual training and validation datasets

    validation_split = 0.2
    split = int(np.floor(validation_split * len(train)))

    indices = list(range(len(train)))
    np.random.shuffle(indices)

    train_indices, validation_indices = indices[split:], indices[:split]

    train_sampler = SubsetRandomSampler(train_indices)
    validation_sampler = SubsetRandomSampler(validation_indices)

    v_train_loader = DataLoader(train, batch_size=args.batch_size, sampler=train_sampler, **kwargs)
    validation_loader = DataLoader(train, batch_size=args.batch_size, sampler=validation_sampler, **kwargs)
    v_test_loader = DataLoader(test, batch_size=args.batch_size, shuffle=False, **kwargs)

    # Creating a subset dataset for training
    train_subset = Subset(train, train_indices)

    #note: is_shuffle here also is a flag for differentiating train and test
    # Split the subsetted dataset further if necessary
    train_loaders = split_data(train_subset, args, kwargs, is_shuffle = True)
    test_loaders = split_data(test,  args, kwargs, is_shuffle = False)

    #return train_loaders, test_loaders, v_train_loader, v_test_loader
    return train_loaders, test_loaders, validation_loader, v_test_loader


def get_cifar10_as_related_preprossesing(dataset_root, args):
    args.get_logger().debug("Loading CIFAR10")
    is_cuda = args.cuda
    kwargs = {'num_workers': 1, 'pin_memory':True} if is_cuda else{}
    # nora pre-processing as stated in the attack paper
    # Data is normalized with mean [0.485, 0.456, 0.406] and standard deviation [0.229, 0.224, 0.225].
    # Values reflect mean and standard deviation of the ImageNet dataset [13]
    # and are commonplace, even expected when using Torchvision [25] models.
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    transform_train = transforms.Compose([
        # We additionally perform data augmentation with random horizontal flipping,
        transforms.RandomHorizontalFlip(),
        # random cropping with size 32, and default padding.
        transforms.RandomCrop(32, 4),
        transforms.ToTensor(),
        normalize
    ])
    # nora tha same pre-processing
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        normalize
    ])
    train = datasets.CIFAR10(os.path.join(dataset_root, 'cifar10'), train = True,
                        download = True, transform = transform_train)
    test = datasets.CIFAR10(os.path.join(dataset_root,'cifar10'), train = False,
                        download = True, transform = transform_test)


    # Splitting train_dataset into actual training and validation datasets
    validation_split = 0.2
    split = int(np.floor(validation_split * len(train)))

    indices = list(range(len(train)))
    np.random.shuffle(indices)

    train_indices, validation_indices = indices[split:], indices[:split]

    train_sampler = SubsetRandomSampler(train_indices)
    validation_sampler = SubsetRandomSampler(validation_indices)

    v_train_loader = DataLoader(train, batch_size=args.batch_size, sampler=train_sampler, **kwargs)
    validation_loader = DataLoader(train, batch_size=args.batch_size, sampler=validation_sampler, **kwargs)
    v_test_loader = DataLoader(test, batch_size=args.batch_size, shuffle=False, **kwargs)

    # Creating a subset dataset for training
    train_subset = Subset(train, train_indices)

    #note: is_shuffle here also is a flag for differentiating train and test
    # Split the subsetted dataset further if necessary
    train_loaders = split_data(train_subset, args, kwargs, is_shuffle = True)
    test_loaders = split_data(test,  args, kwargs, is_shuffle = False)

    #return train_loaders, test_loaders, v_train_loader, v_test_loader
    return train_loaders, test_loaders, validation_loader, v_test_loader

def get_cifar10(dataset_root, args):
    args.get_logger().debug("Loading CIFAR10")
    is_cuda = args.cuda
    kwargs = {'num_workers': 1, 'pin_memory':True} if is_cuda else{}
    # nora pre-processing as stated in the attack paper
    # Data is normalized with mean [0.485, 0.456, 0.406] and standard deviation [0.229, 0.224, 0.225].
    # Values reflect mean and standard deviation of the ImageNet dataset [13]
    # and are commonplace, even expected when using Torchvision [25] models.
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    transform_train = transforms.Compose([
        # We additionally perform data augmentation with random horizontal flipping,
        #transforms.RandomHorizontalFlip(),
        # random cropping with size 32, and default padding.
        #transforms.RandomCrop(32, 4),
        transforms.ToTensor(),
        normalize
    ])
    # nora tha same pre-processing
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    transform_test = transforms.Compose([
        transforms.ToTensor(),
        normalize
    ])
    train = datasets.CIFAR10(os.path.join(dataset_root, 'cifar10'), train = True,
                        download = True, transform = transform_train)
    test = datasets.CIFAR10(os.path.join(dataset_root,'cifar10'), train = False,
                        download = True, transform = transform_test)


    # Splitting train_dataset into actual training and validation datasets
    validation_split = 0.2
    split = int(np.floor(validation_split * len(train)))

    indices = list(range(len(train)))
    np.random.shuffle(indices)

    train_indices, validation_indices = indices[split:], indices[:split]

    train_sampler = SubsetRandomSampler(train_indices)
    validation_sampler = SubsetRandomSampler(validation_indices)

    v_train_loader = DataLoader(train, batch_size=args.batch_size, sampler=train_sampler, **kwargs)
    validation_loader = DataLoader(train, batch_size=args.batch_size, sampler=validation_sampler, **kwargs)
    v_test_loader = DataLoader(test, batch_size=args.batch_size, shuffle=False, **kwargs)

    # Creating a subset dataset for training
    train_subset = Subset(train, train_indices)

    #note: is_shuffle here also is a flag for differentiating train and test
    # Split the subsetted dataset further if necessary
    train_loaders = split_data(train_subset, args, kwargs, is_shuffle = True)
    test_loaders = split_data(test,  args, kwargs, is_shuffle = False)

    #return train_loaders, test_loaders, v_train_loader, v_test_loader
    return train_loaders, test_loaders, validation_loader, v_test_loader

def get_fashion_mnist(dataset_root, args):
    args.get_logger().debug("Loading FashionMNIST")
    is_cuda = args.cuda
    kwargs = {'num_workers': 1, 'pin_memory': True} if is_cuda else {}
    transform = transforms.Compose([transforms.ToTensor()])

    train = datasets.FashionMNIST(os.path.join(dataset_root, 'fashion_mnist'), train=True,
                                  download=True, transform=transform)
    test = datasets.FashionMNIST(os.path.join(dataset_root, 'fashion_mnist'), train=False,
                                 download=True, transform=transform)

    # Get the targets to use for stratified sampling
    targets = train.targets

    # Using sklearn's train_test_split for stratified split
    train_indices, validation_indices, _, _ = train_test_split(
        list(range(len(train))),
        targets,
        test_size=0.2,
        stratify=targets,
        random_state=42  # Set seed for reproducibility
    )

    train_sampler = SubsetRandomSampler(train_indices)
    validation_sampler = SubsetRandomSampler(validation_indices)

    v_train_loader = DataLoader(train, batch_size=args.batch_size, sampler=train_sampler, **kwargs)
    validation_loader = DataLoader(train, batch_size=args.batch_size, sampler=validation_sampler, **kwargs)
    v_test_loader = DataLoader(test, batch_size=args.batch_size, shuffle=False, **kwargs)

    # Creating a subset dataset for training
    train_subset = Subset(train, train_indices)

    # Split the subsetted dataset further if necessary
    train_loaders = split_data(train_subset, args, kwargs, is_shuffle=True)
    test_loaders = split_data(test, args, kwargs, is_shuffle=False)

    return train_loaders, test_loaders, validation_loader, v_test_loader



def show_distribution(dataloader, args):
    """
    show the distribution of the data on certain client with dataloader
    return:
        percentage of each class of the label
    """

    labels = []
    for data, label in dataloader:
        labels.extend(label.numpy().tolist())

    num_samples = len(labels)

    # Assuming 10 classes, labeled 0 through 9
    distribution = np.zeros(10)

    for label in labels:
        distribution[label] += 1

    distribution = distribution / num_samples

    unique_labels = np.where(distribution > 0)[0]
    print(f"Number of unique labels: {len(unique_labels)}")

    # For each class print the distribution
    # for i in range(len(distribution)):
    #     print(f"Percentage of samples in class {i}: {distribution[i] * 100:.3f}%")

    return distribution
