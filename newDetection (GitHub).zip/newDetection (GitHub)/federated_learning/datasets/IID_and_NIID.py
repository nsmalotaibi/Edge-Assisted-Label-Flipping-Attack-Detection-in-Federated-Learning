import copy
from edge import Edge
import numpy as np
from federated_learning.datasets.splitting import show_distribution


def get_client_class(args, clients):
    client_class = []
    client_class_dis = [[],[],[],[],[],[],[],[],[],[]]
    for client in clients:
        train_loader = client.train_loader
        distribution = show_distribution(train_loader, args)
        label = np.argmax(distribution)
        client_class.append(label)
        client_class_dis[label].append(client.client_idx)
    print(client_class_dis)
    return client_class_dis


def get_edge_class(args, edges, clients):
    edge_class = [[], [], [], [], []]
    for (i,edge) in enumerate(edges):
        for cid in edge.cids:
            client = clients[cid]
            train_loader = client.train_loader
            distribution = show_distribution(train_loader, args)
            label = np.argmax(distribution)
            edge_class[i].append(label)
    print(f'class distribution among edge {edge_class}')

# iid =-2 and edgeiid = 1
def initialize_edges_iid(num_edges, clients, args, client_class_dis, validation_loader=None):
    """
    This function is specially designed for partition for 10*L users, 1-class per user, but the distribution among edges is iid,
    10 clients per edge, each edge has 10 classes
    :param num_edges: L
    :param clients: List of client objects
    :param args: Additional arguments
    :param client_class_dis: List of available clients for each class
    :return: List of edge servers and probability of clients for each edge
    """
    #only assign first (num_edges - 1), neglect the last 1, choose the left
    edges = []
    p_clients = [0.0] * num_edges

    for eid in range(num_edges):
        if eid == num_edges - 1:
            break
        assigned_clients_idxes = []

        #     0-9 labels in total
        for label in range(10):
            if not client_class_dis[label]:
                print(f"label {label} is empty")
                continue  # Skip this label if it's empty

            assigned_client_idx = np.random.choice(client_class_dis[label], 1, replace=False)
            for idx in assigned_client_idx:
                assigned_clients_idxes.append(idx)
            client_class_dis[label] = list(set(client_class_dis[label]) - set(assigned_client_idx))

        # Insert debug prints here
        print(f"Edge server {eid} assigned client indices: {assigned_clients_idxes}")
        print(f"client_class_dis after assigning clients to edge server {eid}: ", client_class_dis)

        edges.append(Edge(id=eid,
                          cids=assigned_clients_idxes,
                          model=copy.deepcopy(clients[0].model),
                          args=args,
                          validation_loader=validation_loader))

        [edges[eid].client_register(clients[client]) for client in assigned_clients_idxes]
        edges[eid].all_trainsample_num = sum(edges[eid].sample_registration.values())
        p_clients[eid] = [sample / float(edges[eid].all_trainsample_num)
                          for sample in list(edges[eid].sample_registration.values())]
        edges[eid].refresh_edgeserver()

    # Assign the remaining clients to the last edge server (eid == num_edges - 1)
    eid = num_edges - 1
    assigned_clients_idxes = []

    for label in range(10):
        if not client_class_dis[label]:
            print(f"label {label} is empty")
            continue  # Skip this label if it's empty

        assigned_client_idx = client_class_dis[label]
        for idx in assigned_client_idx:
            assigned_clients_idxes.append(idx)
        client_class_dis[label] = list(set(client_class_dis[label]) - set(assigned_client_idx))

    # Insert debug prints here
    print(f"Edge server {eid} assigned client indices: {assigned_clients_idxes}")
    print(f"client_class_dis after assigning clients to edge server {eid}: ", client_class_dis)

    edges.append(Edge(id=eid,
                      cids=assigned_clients_idxes,
                      model=copy.deepcopy(clients[0].model),
                      args=args,
                      validation_loader=validation_loader))

    [edges[eid].client_register(clients[client]) for client in assigned_clients_idxes]
    edges[eid].all_trainsample_num = sum(edges[eid].sample_registration.values())
    p_clients[eid] = [sample / float(edges[eid].all_trainsample_num)
                      for sample in list(edges[eid].sample_registration.values())]
    edges[eid].refresh_edgeserver()

    return edges, p_clients


# iid =-2 and edgeiid = 0
def initialize_edges_niid(num_edges, clients, args, client_class_dis, validation_loader=None):
    """
    This function is specially designed for partiion for 10*L users, 1-class per user, but the distribution among edges is iid,
    10 clients per edge, each edge have 5 classes
    :param num_edges: L
    :param clients:
    :param args:
    :return:
    """
    #only assign first (num_edges - 1), neglect the last 1, choose the left
    edges = []
    p_clients = [0.0] * num_edges
    label_ranges = [[0,1,2,3,4],[1,2,3,4,5],[5,6,7,8,9],[6,7,8,9,0]]
    for eid in range(num_edges):
        if eid == num_edges - 1:
            break
        assigned_clients_idxes = []
        label_range = label_ranges[eid]
        for i in range(2):
            for label in label_range:
                #     5 labels in total
                if len(client_class_dis[label]) > 0:
                    assigned_client_idx = np.random.choice(client_class_dis[label], 1, replace=False)
                    client_class_dis[label] = list(set(client_class_dis[label]) - set(assigned_client_idx))
                else:
                    label_backup = 2
                    assigned_client_idx = np.random.choice(client_class_dis[label_backup],1, replace=False)
                    client_class_dis[label_backup] = list(set(client_class_dis[label_backup]) - set(assigned_client_idx))
                for idx in assigned_client_idx:
                    assigned_clients_idxes.append(idx)

        # Insert debug prints here
        print(f"Edge server {eid} assigned client indices: {assigned_clients_idxes}")
        print(f"client_class_dis after assigning clients to edge server {eid}: ", client_class_dis)

        edges.append(Edge(id = eid,
                          cids=assigned_clients_idxes,
                          model=copy.deepcopy(clients[0].model),
                          args=args,
                          validation_loader=validation_loader))
        [edges[eid].client_register(clients[client]) for client in assigned_clients_idxes]
        edges[eid].all_trainsample_num = sum(edges[eid].sample_registration.values())
        p_clients[eid] = [sample / float(edges[eid].all_trainsample_num)
                        for sample in list(edges[eid].sample_registration.values())]
        edges[eid].refresh_edgeserver()
    #And the last one, eid == num_edges -1
    #Find the last available labels
    eid = num_edges - 1
    assigned_clients_idxes = []
    for label in range(10):
        if not client_class_dis[label]:
            print("label{} is empty".format(label))
        else:
            assigned_client_idx = client_class_dis[label]
            for idx in assigned_client_idx:
                assigned_clients_idxes.append(idx)
            client_class_dis[label] = list(set(client_class_dis[label]) - set(assigned_client_idx))

    # Insert debug prints here
    print(f"Edge server {eid} assigned client indices: {assigned_clients_idxes}")
    print(f"client_class_dis after assigning clients to edge server {eid}: ", client_class_dis)

    edges.append(Edge(id=eid,
                      cids=assigned_clients_idxes,
                      model=copy.deepcopy(clients[0].model),
                      args=args,
                      validation_loader=validation_loader))
    [edges[eid].client_register(clients[client]) for client in assigned_clients_idxes]
    edges[eid].all_trainsample_num = sum(edges[eid].sample_registration.values())
    p_clients[eid] = [sample / float(edges[eid].all_trainsample_num)
                    for sample in list(edges[eid].sample_registration.values())]
    edges[eid].refresh_edgeserver()
    return edges, p_clients