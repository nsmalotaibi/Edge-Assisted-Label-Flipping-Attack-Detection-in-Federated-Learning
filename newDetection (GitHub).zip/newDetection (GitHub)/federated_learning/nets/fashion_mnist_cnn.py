import torch
import torch.nn as nn
import torch.nn.functional as F


class FashionMNISTCNN(nn.Module):

    def __init__(self):
        # nora The super() function is used to give access to methods and properties of a parent or sibling class.
        # nora The super() function returns an object that represents the parent class.
        super(FashionMNISTCNN, self).__init__()

        # Define the first convolutional layer and its operations
        self.layer1 = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=5, padding=2),  # Convolutional layer with 1 input channel, 16 output channels, kernel size of 5x5, and padding of 2
            nn.BatchNorm2d(16),  # Batch normalization layer with 16 channels
            nn.ReLU(),  # ReLU activation function
            nn.MaxPool2d(2)  # Max pooling layer with kernel size of 2x2
        )

        # Define the second convolutional layer and its operations
        self.layer2 = nn.Sequential(
            nn.Conv2d(16, 32, kernel_size=5, padding=2),  # Convolutional layer with 16 input channels, 32 output channels, kernel size of 5x5, and padding of 2
            nn.BatchNorm2d(32),  # Batch normalization layer with 32 channels
            nn.ReLU(),  # ReLU activation function
            nn.MaxPool2d(2)  # Max pooling layer with kernel size of 2x2
        )

        # Define the fully connected layer
        self.fc = nn.Linear(7*7*32, 10)  # Fully connected layer with input size of 7*7*32 and output size of 10

    def forward(self, x):
        # Pass the input through the first convolutional layer and its operations
        x = self.layer1(x)

        # Pass the output of the first layer through the second convolutional layer and its operations
        x = self.layer2(x)

        # Flatten the tensor for the fully connected layer
        x = x.view(x.size(0), -1)

        # Pass the flattened tensor through the fully connected layer
        x = self.fc(x)

        return x

    def get_activations(self, x):
        activations = {}

        # Activations after layer 1
        a1 = self.layer1(x)
        activations["layer1"] = a1

        # Activations after layer 2
        a2 = self.layer2(a1)
        activations["layer2"] = a2

        # Activations after fully connected layer (before softmax or final activation)
        a3 = self.fc(a2.view(a2.size(0), -1))
        activations["fc"] = a3

        return activations


    def get_gradients(self):
        gradients = {
            "layer1_conv_weight": self.layer1[0].weight.grad,
            "layer1_conv_bias": self.layer1[0].bias.grad,
            "layer1_bn_weight": self.layer1[1].weight.grad,
            "layer1_bn_bias": self.layer1[1].bias.grad,
            "layer2_conv_weight": self.layer2[0].weight.grad,
            "layer2_conv_bias": self.layer2[0].bias.grad,
            "layer2_bn_weight": self.layer2[1].weight.grad,
            "layer2_bn_bias": self.layer2[1].bias.grad,
            "fc_weight": self.fc.weight.grad,
            "fc_bias": self.fc.bias.grad
        }
        return gradients


    def get_gradient_for_layer(self, layer_name):
        """
        Get the gradient for a specific layer given its name.

        Args:
            layer_name (str): Name of the layer (e.g., "layer1_conv", "layer2_bn").

        Returns:
            Tensor: Gradient for the specified layer. None if layer name is invalid.
        """
        gradient_map = {
            "layer1_conv_weight": self.layer1[0].weight.grad,
            "layer1_conv_bias": self.layer1[0].bias.grad,
            "layer1_bn_weight": self.layer1[1].weight.grad,
            "layer1_bn_bias": self.layer1[1].bias.grad,
            "layer2_conv_weight": self.layer2[0].weight.grad,
            "layer2_conv_bias": self.layer2[0].bias.grad,
            "layer2_bn_weight": self.layer2[1].weight.grad,
            "layer2_bn_bias": self.layer2[1].bias.grad,
            "fc_weight": self.fc.weight.grad,
            "fc_bias": self.fc.bias.grad
        }

        gradient = gradient_map.get(layer_name, None)

        # Logging
        if gradient is None:
            print(f"Gradient for {layer_name} is None.")
        else:
            print(f"Gradient for {layer_name} exists and has shape: {gradient.shape}")

        return gradient


"""
Explanation:

The FashionMNISTCNN class is defined as a subclass of nn.Module, the base class for all neural network modules in PyTorch.
The __init__ method is called when an object of the class is instantiated. It initializes the layers of the network.
Two convolutional layers are defined, layer1 and layer2, along with their respective operations.
Each convolutional layer is defined as a nn.Sequential module, which allows sequential execution of multiple layers.
Batch normalization (nn.BatchNorm2d) is applied after each convolutional layer to normalize the input channels.
ReLU activation (nn.ReLU) is used to introduce non-linearity after each batch normalization layer.
Max pooling (nn.MaxPool2d) is applied to reduce the spatial dimensions of the feature maps.
The fully connected layer (self.fc) is defined with an input size of 7x7x32 (resulting from the previous layers) and an output size of 10 (for the 10 output classes of the FashionMNIST dataset).
The forward method defines the forward pass of the network, specifying how input flows through the layers.
In the forward method, the input tensor x is passed through layer1 and layer2 successively.
The tensor is then flattened using view to be compatible with the fully connected layer.
Finally, the flattened tensor is passed through the fully connected layer
"""
"""
Summary:

The FashionMNISTCNN class defines a convolutional neural network for FashionMNIST image classification.
It consists of two convolutional layers with batch normalization, ReLU activation, and max pooling operations.
The fully connected layer is followed by a linear transformation to produce the final output.
The forward method implements the forward pass through the network, applying the defined layers sequentially.

This code can be represented as:
Conv1-BN1-Relu-MaxPool1-Conv2-BN2-Relu-MaxPool2-FC

in the attack paper 
layer1:   Conv∗1+BN∗1+Relu +MaxPool∗1+FC∗1  
layer 2 : Conv ∗ 1+BN ∗ 1+Relu+MaxPool ∗ 1+FC ∗ 1 



Explanation:

Conv1: 1 input channel, 16 output channels, kernel size 5x5, padding 2
BN1: Batch normalization with 16 channels
Relu: ReLU activation function
MaxPool1: Max pooling with kernel size 2x2
Conv2: 16 input channels, 32 output channels, kernel size 5x5, padding 2
BN2: Batch normalization with 32 channels
Relu: ReLU activation function
MaxPool2: Max pooling with kernel size 2x2
FC: Fully connected layer with input size 7x7x32 (resulting from the previous layers) and output size 10
Note: Softmax is not explicitly included in the code provided, but it's often applied during the training or inference process to obtain probability distributions over the classes.
"""