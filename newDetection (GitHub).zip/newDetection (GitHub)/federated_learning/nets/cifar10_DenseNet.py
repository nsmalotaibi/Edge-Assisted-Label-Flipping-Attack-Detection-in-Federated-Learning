import torch
import torch.nn as nn
import torch.nn.functional as F


class DenseBlock(nn.Module):
    def __init__(self, in_channels, growth_rate, num_layers):
        super(DenseBlock, self).__init__()
        self.layers = nn.ModuleList()
        for i in range(num_layers):
            self.layers.append(self._make_layer(in_channels + i * growth_rate, growth_rate))

    def _make_layer(self, in_channels, growth_rate):
        return nn.Sequential(
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, growth_rate, kernel_size=3, padding=1, bias=False)
        )

    def forward(self, x):
        features = [x]
        for layer in self.layers:
            new_features = layer(torch.cat(features, 1))
            features.append(new_features)
        return torch.cat(features, 1)


class TransitionLayer(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(TransitionLayer, self).__init__()
        self.layer = nn.Sequential(
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.AvgPool2d(kernel_size=2, stride=2)
        )

    def forward(self, x):
        return self.layer(x)


class Cifar10DenseNet(nn.Module):
    def __init__(self, growth_rate=12, block_layers=[6, 12, 24]):
        super(Cifar10DenseNet, self).__init__()
        self.growth_rate = growth_rate
        num_channels = 2 * growth_rate

        self.conv1 = nn.Conv2d(3, num_channels, kernel_size=3, padding=1, bias=False)

        self.block1 = DenseBlock(num_channels, growth_rate, block_layers[0])
        num_channels += block_layers[0] * growth_rate
        self.trans1 = TransitionLayer(num_channels, num_channels // 2)
        num_channels = num_channels // 2

        self.block2 = DenseBlock(num_channels, growth_rate, block_layers[1])
        num_channels += block_layers[1] * growth_rate
        self.trans2 = TransitionLayer(num_channels, num_channels // 2)
        num_channels = num_channels // 2

        self.block3 = DenseBlock(num_channels, growth_rate, block_layers[2])
        num_channels += block_layers[2] * growth_rate

        self.bn = nn.BatchNorm2d(num_channels)
        self.fc = nn.Linear(96 * 8 * 8, 10)  # Adjusted input dimensions for the fully connected layer

    def forward(self, x):
        x = self.conv1(x)
        x = self.block1(x)
        x = self.trans1(x)
        # print(x.shape)  # Debug print
        x = self.block2(x)
        x = self.trans2(x)
        # print(x.shape)  # Debug print
        x = self.block3(x)
        x = self.bn(x)
        x = F.relu(x)
        x = F.avg_pool2d(x, kernel_size=2).view(x.size(0), -1)  # Adjust the pooling kernel size
        # print(x.shape)  # Debug print
        x = self.fc(x)
        return F.log_softmax(x, dim=1)

