import torch.nn as nn
import torch.nn.functional as F

class MNISTCNN(nn.Module):

    def __init__(self):
        super(MNISTCNN, self).__init__()

        self.conv1 = nn.Conv2d(1, 10, kernel_size=5)  # First convolutional layer: 1 input channel, 10 output channels, kernel size of 5x5
        self.conv2 = nn.Conv2d(10, 20, kernel_size=5)  # Second convolutional layer: 10 input channels, 20 output channels, kernel size of 5x5
        self.conv2_drop = nn.Dropout2d()  # Dropout layer to randomly zero out elements during training
        self.fc1 = nn.Linear(320, 50)  # First fully connected layer: input size 320, output size 50
        self.fc2 = nn.Linear(50, 10)  # Second fully connected layer: input size 50, output size 10

    def forward(self, x):
        x = self.conv1(x)  # Pass input through the first convolutional layer
        x = F.max_pool2d(x, 2)  # Apply max pooling with kernel size 2x2
        x = F.relu(x)  # Apply ReLU activation
        x = self.conv2(x)  # Pass output of previous layer through the second convolutional layer
        x = self.conv2_drop(x)  # Apply dropout to the output of the second convolutional layer
        x = F.max_pool2d(x, 2)  # Apply max pooling with kernel size 2x2
        x = F.relu(x)  # Apply ReLU activation
        x = x.view(-1, x.shape[1] * x.shape[2] * x.shape[3])  # Reshape tensor for the fully connected layer
        x = self.fc1(x)  # Pass the flattened tensor through the first fully connected layer
        x = F.relu(x)  # Apply ReLU activation
        x = F.dropout(x, training=self.training)  # Apply dropout regularization during training
        x = self.fc2(x)  # Pass the output of the previous layer through the second fully connected layer
        return x


"""Short form summary:
Conv1-Relu-MaxPool2d-Conv2-Dropout-MaxPool2d-Flatten-FC1-Relu-Dropout-FC2

Explanation:

Conv1: 1 input channel, 10 output channels, kernel size 5x5
Relu: ReLU activation function
MaxPool2d: Max pooling with kernel size 2x2
Conv2: 10 input channels, 20 output channels, kernel size 5x5
Dropout: Dropout regularization to prevent overfitting
Flatten: Reshape tensor for the fully connected layers
FC1: First fully connected layer with input size 320 and output size 50
Relu: ReLU activation function
Dropout: Dropout regularization
FC2: Second fully connected layer with input size 50 and output size 10
Note: Softmax is not included explicitly, but it is often applied during the training or inference process to obtain probability distributions over the classes."""