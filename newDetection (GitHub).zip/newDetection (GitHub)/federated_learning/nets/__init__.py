from .cifar_10_cnn import Cifar10CNN
from .cifar_100_cnn import Cifar100CNN
from .fashion_mnist_cnn import FashionMNISTCNN
from .mnist_cnn import MNISTCNN
from .cifar10_DenseNet import Cifar10DenseNet