# The structure of the cloud server
# The cloud server should include the following functions:
# 1. Cloud initialization, edge registration
# 2. Cloud receives updates from the edges
# 3. Cloud aggregates and sends the aggregated information back to edges
import copy
from average import average_weights

class Cloud():

    def __init__(self, model):
        self.receiver_buffer = {}
        self.model_state_dict = {}
        self.id_registration = []
        self.sample_registration = {}
        self.clock = []

    def refresh_cloudserver(self):
        self.receiver_buffer.clear()
        del self.id_registration[:]
        self.sample_registration.clear()
        return None

    def edge_register(self, edge):
        self.id_registration.append(edge.id)
        self.sample_registration[edge.id] = edge.all_trainsample_num
        return None

    def receive_from_edge(self, edge_id, emodel_state_dict):
        self.receiver_buffer[edge_id] = emodel_state_dict
        return None

    def aggregate(self, args):
        received_dict = [dict for dict in self.receiver_buffer.values()]
        sample_num = [snum for snum in self.sample_registration.values()]
        self.model_state_dict = average_weights(w=received_dict,
                                                 s_num=sample_num)
        return None

    def send_to_edge(self, edge):
        edge.receive_from_cloudserver(copy.deepcopy(self.model_state_dict))
        return None

    def correctly_identified_malicious_clients_metrics(self, cloud_identified_malicious_clients,
                                                       actual_malicious_clients, all_client_ids):
        # Convert lists to sets for easier computation
        identified_set = set(cloud_identified_malicious_clients)
        actual_set = set(actual_malicious_clients)  # Represents all actual malicious clients in the system
        all_clients_set = set(all_client_ids)  # Represents all clients in the system

        # True Positives (TP): Identified and actually malicious
        true_positives = len(identified_set.intersection(actual_set))

        # False Positives (FP): Identified but not actually malicious
        false_positives = len(identified_set.difference(actual_set))

        # False Negatives (FN): Actually malicious but not identified
        false_negatives = len(actual_set.difference(identified_set))

        # True Negatives (TN): Not identified and not malicious
        true_negatives = len(all_clients_set.difference(actual_set.union(identified_set)))

        # TPR (Recall or Sensitivity)
        tpr = true_positives / (true_positives + false_negatives) if true_positives + false_negatives > 0 else 0

        # FPR
        fpr = false_positives / (false_positives + true_negatives) if false_positives + true_negatives > 0 else 0

        # Accuracy
        accuracy = (true_positives + true_negatives) / (
                    true_positives + false_positives + false_negatives + true_negatives) if (
                                                                                                        true_positives + false_positives + false_negatives + true_negatives) > 0 else 0

        # Check if all actual malicious clients are correctly identified
        all_malicious_identified = false_negatives == 0

        return tpr, fpr, accuracy, true_positives, false_positives, false_negatives, true_negatives, all_malicious_identified
