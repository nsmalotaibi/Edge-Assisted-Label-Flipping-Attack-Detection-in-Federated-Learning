import copy
import torch

def average_weights(w, s_num):
    # Calculate the total number of samples across all clients
    total_sample_num = sum(s_num)

    # Get the sample number of the first client
    temp_sample_num = s_num[0]

    # Create a deep copy of the first client's weights
    w_avg = copy.deepcopy(w[0])

    # Convert each tensor in w_avg to FloatTensor
    for key in w_avg.keys():
        w_avg[key] = w_avg[key].float()

    # Iterate over each layer (key) in the weights
    for k in w_avg.keys(): #the nn layer loop
        # Iterate over the remaining clients
        for i in range(1, len(w)): #the client loop
            # Accumulate the weighted sum of the weights
            w_avg[k] += torch.mul(w[i][k].to(torch.float32), s_num[i] / temp_sample_num)

        # Scale the accumulated weights by the ratio of the first client's sample number to the total sample number
        w_avg[k] = torch.mul(w_avg[k], temp_sample_num / total_sample_num)

    # Return the average weights
    return w_avg
