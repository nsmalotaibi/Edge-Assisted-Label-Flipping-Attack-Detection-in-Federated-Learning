# The structure of the edge server
# The edge should include following funcitons
# 1. Server initialization
# 2. Server receives updates from the client
# 3. Server sends the aggregated information back to clients
# 4. Server sends the updates to the cloud server
# 5. Server receives the aggregated information from the cloud server
import statistics
import time
import torch
import copy
from average import average_weights

class Edge():

    def __init__(self, args, id, cids, model, validation_loader):
        """
        :param id: Index of the edge
        :param cids: Indexes of all the clients under this edge
        receiver_buffer: buffer for the received updates from selected clients
        shared_state_dict: state dict for shared network
        id_registration: participated clients in this round of traning
        sample_registration: number of samples of the participated clients in this round of training
        all_trainsample_num: the training samples for all the clients under this edge
        shared_state_dict: the dictionary of the shared state dict
        clock: record the time after each aggregation
        """
        self.args = args
        self.id = id
        self.cids = cids
        self.receiver_buffer = {}
        self.client_send_times = {}
        self.client_receive_times = {}
        self.id_registration = []
        self.sample_registration = {}
        self.all_trainsample_num = 0
        self.model_state_dict = model.state_dict()
        self.clock = []
        self.client_gradients = {}  # Initialize the dictionary attribute
        self.model = model  # Store the model reference
        self.client_performances = {}
        self.baseline_model = None
        self.validation_loader = validation_loader

    def get_edge_id(self):
        """
        Returns the edge id.
        """
        return self.id


    def refresh_edgeserver(self):
        self.receiver_buffer.clear()
        self.client_send_times.clear()
        self.client_receive_times.clear()
        del self.id_registration[:]
        self.sample_registration.clear()
        return None

    def client_register(self, client):
        self.id_registration.append(client.client_idx)
        self.sample_registration[client.client_idx] = len(client.train_loader.dataset)
        # added
        if not self.validation_loader:
            self.validation_loader = client.validation_loader
        return None

    def send_to_client(self, client):
        client.receive_from_edgeserver(copy.deepcopy(self.model_state_dict))
        return None

    def receive_from_client(self, client_id, cmodel_state_dict, send_time):
        receive_time = time.time()  # Time of receiving the update
        # Store send_time, in a structure that associates it with the client_id
        self.receiver_buffer[client_id] = cmodel_state_dict
        self.client_send_times[client_id] = send_time
        self.client_receive_times[client_id] = receive_time  # New attribute to store receive times

        return None

    def send_to_cloudserver(self, cloud):
        cloud.receive_from_edge(edge_id=self.id,
                                emodel_state_dict= copy.deepcopy(
                                    self.model_state_dict))
        return None

    def receive_from_cloudserver(self, model_state_dict):
        self.model_state_dict = model_state_dict
        return None

    def accept_client_gradient(self, client_id, gradient):
        # This function will be called after each client's training.
        self.client_gradients[client_id] = gradient

    def aggregate(self, args):

        received_dict = [dict for dict in self.receiver_buffer.values()]
        sample_num = [snum for snum in self.sample_registration.values()]
        self.model_state_dict = average_weights(w=received_dict, s_num=sample_num)

        return None

    def aggregate_excluding(self, args, exclude_clients=None):
        """
        Modified aggregation to incorporate attack detection and exclusion of malicious clients.
        :param args: Arguments or configuration parameters
        :param exclude_clients: A list of client IDs to be excluded from aggregation
        """
        if exclude_clients is None:
            exclude_clients = []

        # Check and print information about excluded clients
        if exclude_clients:
            excluded_ids = ', '.join(map(str, exclude_clients))
            args.get_logger().info(f"Excluding malicious clients: {excluded_ids}")
        else:
            args.get_logger().info("No clients are excluded from aggregation.")

        # Filter out the state dicts of excluded clients
        valid_receiver_buffer = {client_id: state_dict for client_id, state_dict in self.receiver_buffer.items()
                                 if client_id not in exclude_clients}

        # Proceed with aggregation only if there are valid clients
        if valid_receiver_buffer:
            received_dict = [state_dict for state_dict in valid_receiver_buffer.values()]
            sample_num = [self.sample_registration[client_id] for client_id in valid_receiver_buffer.keys()]
            self.model_state_dict = average_weights(w=received_dict, s_num=sample_num)
        else:
            args.get_logger().info("No valid clients for aggregation.")

        return None


    def set_validation_loader(self, validation_loader):
        """
        Sets the validation loader for the edge server.
        """
        self.validation_loader = validation_loader



    ################################ edge.baseline_model detection ############################################
    def set_baseline_model(self, model):
        self.baseline_model = copy.deepcopy(model)

    def validate_client_update_using_baseline_model(self, model_to_evaluate, validation_data, args):
        model_to_evaluate = model_to_evaluate.to(args.device)
        model_to_evaluate.eval()  # Set model to evaluation mode
        correct = 0
        total = 0
        with torch.no_grad():  # Deactivate autograd
            for data, labels in validation_data:
                data, labels = data.to(args.device), labels.to(args.device)  # Move data and labels to the correct device
                outputs = model_to_evaluate(data)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        accuracy = correct / total
        return accuracy

    def calculate_class_accuracy(self, model_to_evaluate, validation_data, args):
        model_to_evaluate = model_to_evaluate.to(args.device)
        model_to_evaluate.eval()
        class_correct = {}
        class_total = {}

        with torch.no_grad():
            for data, labels in validation_data:
                data, labels = data.to(args.device), labels.to(args.device)  # Move data and labels to the correct device
                outputs = model_to_evaluate(data)
                _, predicted = torch.max(outputs, 1)

                for label, prediction in zip(labels, predicted):
                    label = label.item()
                    if label not in class_correct:
                        class_correct[label] = 0
                        class_total[label] = 0
                    if label == prediction:
                        class_correct[label] += 1
                    class_total[label] += 1

        # Calculate class-wise accuracy
        class_accuracies = {cls: class_correct[cls] / class_total[cls] if class_total[cls] > 0 else 0 for cls in
                            class_correct.keys()}
        return class_accuracies

    def compare_classwise_accuracies(self, client_accuracies, edge_model_accuracies):
        discrepancies = {}
        for client_id, client_class_accuracies in client_accuracies.items():
            client_discrepancies = {}
            for class_id, client_accuracy in client_class_accuracies.items():
                edge_accuracy = edge_model_accuracies.get(class_id, 0)
                if edge_accuracy > 0:
                    # Calculate percentage discrepancy relative to edge accuracy
                    discrepancy = (client_accuracy - edge_accuracy) / edge_accuracy
                else:
                    discrepancy = client_accuracy - edge_accuracy
                client_discrepancies[class_id] = discrepancy
            discrepancies[client_id] = client_discrepancies
        return discrepancies

    def format_header_row(self, client_id_width, class_id_width, accuracy_width, discrepancy_width):
        return f"{'Client ID':<{client_id_width}}{'Class ID':<{class_id_width}}{'Accuracy':<{accuracy_width}}{'Discrepancy':<{discrepancy_width}}\n"

    def format_data_row(self, client_id, class_id, accuracy, discrepancy, client_id_width, class_id_width, accuracy_width,
                        discrepancy_width):
        # Ensure accuracy is a float before formatting
        if isinstance(accuracy, str):
            formatted_accuracy = accuracy
        else:
            formatted_accuracy = f"{accuracy:.3%}"

        return f"{client_id:<{client_id_width}}{class_id:<{class_id_width}}{formatted_accuracy:<{accuracy_width}}{discrepancy:<{discrepancy_width}}\n"

    def identify_malicious_clients_by_std_dev(self, performance_dict_edge):
        # Extract only the overall accuracies
        overall_accuracies = [acc["overall_accuracy_on_validationDS"] for acc in performance_dict_edge.values()]
        clients = list(performance_dict_edge.keys())

        # Calculate mean and standard deviation of overall accuracies
        mean_accuracy = sum(overall_accuracies) / len(overall_accuracies)
        std_dev = statistics.stdev(overall_accuracies)
        threshold = mean_accuracy - std_dev
        #threshold = mean_accuracy - (0.75* std_dev)

        # Collect potential malicious clients
        malicious_clients = [client_id for client_id, acc in performance_dict_edge.items() if
                             acc["overall_accuracy_on_validationDS"] < threshold]

        # Check for malicious clients and print accordingly
        if len(malicious_clients) == 0:
            print("No malicious client detected using std_dev.")
        else:
            print(f"{len(malicious_clients)} malicious client(s) detected using std_dev.")
            for client_id in malicious_clients:
                print(
                    f"Client ID: {client_id}, Overall Accuracy: {performance_dict_edge[client_id]['overall_accuracy_on_validationDS']:.3%}")

        return malicious_clients


    def correctly_identified_malicious_clients_metrics(self, identified, actual_malicious_clients, edge_clients):
        # Convert lists to sets for easier computation
        identified_set = set(identified)
        actual_set = set(actual_malicious_clients).intersection(set(edge_clients))
        all_clients_set = set(edge_clients)

        # True Positives (TP): Identified and actually malicious
        true_positives = len(identified_set.intersection(actual_set))

        # False Positives (FP): Identified but not actually malicious
        false_positives = len(identified_set.difference(actual_set))

        # False Negatives (FN): Actually malicious but not identified
        false_negatives = len(actual_set.difference(identified_set))

        # True Negatives (TN): Not identified and not malicious
        true_negatives = len(all_clients_set.difference(actual_set.union(identified_set)))

        # TPR (Recall or Sensitivity)
        tpr = true_positives / (true_positives + false_negatives) if true_positives + false_negatives > 0 else 0

        # FPR
        fpr = false_positives / (false_positives + true_negatives) if false_positives + true_negatives > 0 else 0
        accuracy_of_correctly = (true_positives + true_negatives) / (
                    true_positives + false_positives + false_negatives + true_negatives) if (
                                                                                                        true_positives + false_positives + false_negatives + true_negatives) > 0 else 0

        return tpr, fpr, accuracy_of_correctly, true_positives, false_positives, false_negatives, true_negatives

