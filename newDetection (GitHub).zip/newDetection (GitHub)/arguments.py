from federated_learning.nets import Cifar10CNN, Cifar100CNN, FashionMNISTCNN, MNISTCNN
import torch
import json

from federated_learning.nets.cifar10_DenseNet import Cifar10DenseNet

# Setting the seed for Torch
SEED = 1
torch.manual_seed(SEED)

class Arguments:
    def __init__(self, logger):
        self.logger = logger
        self.log()
        self.discrepancy_detection_threshold = -0.91

        self.isattack = 1
        # -----------list of nets: FashionMNISTCNN , Cifar10CNN, MNISTCNN, Cifar100CNN, VGG16, Cifar10DenseNet
        self.model = FashionMNISTCNN
        # -----------list of datasets: fashion_mnist, cifar10, mnist, cifar100
        self.dataset = 'fashion_mnist'

        # ------------------------------start these are taken form attack
        self.batch_size = 20
        self.test_batch_size = 10
        self.lr = 0.01
        self.momentum = 0.5
        self.cuda = 1 #torch.cuda.is_available()
        # self.shuffle = False
        self.log_interval = 100
        self.kwargs = {}
        self.scheduler_step_size = 50
        self.scheduler_gamma = 0.5
        self.min_lr = 1e-10
        self.save_model = False
        self.save_epoch_interval = 1
        self.save_model_path = "models"
        self.epoch_save_start_suffix = "start"
        self.epoch_save_end_suffix = "end"
        self.num_clients = 50 # from Hier
        # ------------------------------end these are taken form attack

        self.seed = 1
        self.gpu = 1
        self.mtl_model = 0
        self.global_model = 1
        #self.local_model = 0

        # nora define number of num_edges, frac, num_communication, ... as options in running Hierfav.py
        # self.dataset = I guess no need since it written down in self.train_data_loader_pickle_path
        # self.model = no need since it written down as self.net
        self.num_edges = 5
        self.frac = 1 # fraction of participated clients
        self.num_communication = 101 # = epoch
        self.epochs = 101 # = num_communication
        self.num_local_update = 5 # k1 num_local_update&num_edge_aggregation together known as local iteration
        self.num_edge_aggregation = 1 # k2
        # setting for federeated learning
        # iid: distribution of the data, 1,0, -2(one-class)
        # 0: (each client has only two classes of the network)
        # 1: (each client has subset of all classes of the network)
        # -2:
        self.iid = 1
        # edgeiid: distribution of the data under edges, 1 (edgeiid), 0 (edgeniid) (used only when iid = -2)
        self.edgeiid = 0
        # whether to show distribution
        self.show_dis = 1

        #self.dataset_root = 'data'


        # from attack
        #self.train_data_loader_pickle_path = "data_loaders/cifar10/train_data_loader.pickle"
        #self.test_data_loader_pickle_path = "data_loaders/cifar10/test_data_loader.pickle"

        #self.train_data_loader_pickle_path = "data_loaders/mnist/train_data_loader.pickle"
        #self.test_data_loader_pickle_path = "data_loaders/mnist/test_data_loader.pickle"


        #self.train_data_loader_pickle_path = "data_loaders/fashion-mnist/train_data_loader.pickle"
        #self.test_data_loader_pickle_path = "data_loaders/fashion-mnist/test_data_loader.pickle"


        #self.train_data_loader_pickle_path = "data_loaders/cifar100/train_data_loader.pickle"
        #self.test_data_loader_pickle_path = "data_loaders/cifar100/test_data_loader.pickle"

        self.loss_function = torch.nn.CrossEntropyLoss

        self.default_model_folder_path = "default_models"

        self.data_path = "data"

    def set_device(self, device):
        self.device = device

    def get_round_worker_selection_strategy(self):
        return self.round_worker_selection_strategy

    def get_round_worker_selection_strategy_kwargs(self):
        return self.round_worker_selection_strategy_kwargs

    def set_round_worker_selection_strategy_kwargs(self, kwargs):
        self.round_worker_selection_strategy_kwargs = kwargs

    def set_client_selection_strategy(self, strategy):
        self.round_worker_selection_strategy = strategy

    def get_data_path(self):
        return self.data_path

    def get_epoch_save_start_suffix(self):
        return self.epoch_save_start_suffix

    def get_epoch_save_end_suffix(self):
        return self.epoch_save_end_suffix

    def set_train_data_loader_pickle_path(self, path):
        self.train_data_loader_pickle_path = path

    def get_train_data_loader_pickle_path(self):
        return self.train_data_loader_pickle_path

    def set_test_data_loader_pickle_path(self, path):
        self.test_data_loader_pickle_path = path

    def get_test_data_loader_pickle_path(self):
        return self.test_data_loader_pickle_path

    def get_cuda(self):
        return self.cuda

    def get_scheduler_step_size(self):
        return self.scheduler_step_size

    def get_scheduler_gamma(self):
        return self.scheduler_gamma

    def get_min_lr(self):
        return self.min_lr

    def get_default_model_folder_path(self):
        return self.default_model_folder_path

    def get_num_epochs(self):
        return self.epochs

    def set_num_poisoned_workers(self, num_poisoned_workers):
        self.num_poisoned_workers = num_poisoned_workers

    def set_replacement_method(self, replacement_method):
        self.replacement_method = replacement_method

    def set_num_workers(self, num_workers):
        self.num_workers = num_workers

    def set_model_save_path(self, save_model_path):
        self.save_model_path = save_model_path

    def get_logger(self):
        return self.logger

    def get_loss_function(self):
        return self.loss_function

    def get_model(self):
        return self.model


    def get_num_clients(self):
        return self.num_clients

    def get_num_poisoned_workers(self):
        return self.num_poisoned_workers

    def get_learning_rate(self):
        return self.lr

    def get_momentum(self):
        return self.momentum

    def get_shuffle(self):
        return self.shuffle

    def get_batch_size(self):
        return self.batch_size

    def get_test_batch_size(self):
        return self.test_batch_size

    def get_log_interval(self):
        return self.log_interval

    def get_save_model_folder_path(self):
        return self.save_model_path

    def get_isattack(self):
        return self.isattack

    # nora num_edges, frac, ... as in running Hierfav.py
    def get_num_edges(self):
        return self.num_edges

    def get_iid(self):
        return self.iid

    def get_edgeiid(self):
        return self.edgeiid

    def get_frac(self):
        return self.frac

    def get_num_communication(self):
        return self.num_communication

    def get_num_local_update(self):
        return self.num_local_update

    def get_num_edge_aggregation(self):
        return self.num_edge_aggregation

    def get_show_dis(self):
        return self.show_dis

    def get_dataset(self):
        return self.dataset

    def get_learning_rate_from_epoch(self, epoch_idx):
        lr = self.lr * (self.scheduler_gamma ** int(epoch_idx / self.scheduler_step_size))

        if lr < self.min_lr:
            self.logger.warning("Updating LR would place it below min LR. Skipping LR update.")

            return self.min_lr

        self.logger.debug("LR: {}".format(lr))

        return lr

    def should_save_model(self, epoch_idx):
        """
        Returns true/false models should be saved.

        :param epoch_idx: current training epoch index
        :type epoch_idx: int
        """
        if not self.save_model:
            return False

        if epoch_idx == 1 or epoch_idx % self.save_epoch_interval == 0:
            return True

    def log(self):
        """
        Log this arguments object to the logger.
        """
        # nora set logging level to debug instead of the default 'WARN'
        # nora the log file found in logs folder start with "Arguments: {}" then the (self)
        self.logger.debug("Arguments: {}", str(self))
        self.get_logger().info("Arguments instance created with initial settings.")

def __str__(self):
    return "\nBatch Size: {}\n".format(self.batch_size) + \
           "Test Batch Size: {}\n".format(self.test_batch_size) + \
           "Epochs: {}\n".format(self.epochs) + \
           "Learning Rate: {}\n".format(self.lr) + \
           "Momentum: {}\n".format(self.momentum) + \
           "CUDA Enabled: {}\n".format(self.cuda) + \
           "Shuffle Enabled: {}\n".format(self.shuffle) + \
           "Log Interval: {}\n".format(self.log_interval) + \
           "Scheduler Step Size: {}\n".format(self.scheduler_step_size) + \
           "Scheduler Gamma: {}\n".format(self.scheduler_gamma) + \
           "Scheduler Minimum Learning Rate: {}\n".format(self.min_lr) + \
           "Client Selection Strategy: {}\n".format(self.round_worker_selection_strategy) + \
           "Client Selection Strategy Arguments: {}\n".format(
               json.dumps(self.round_worker_selection_strategy_kwargs, indent=4, sort_keys=True)) + \
           "Model Saving Enabled: {}\n".format(self.save_model) + \
           "Model Saving Interval: {}\n".format(self.save_epoch_interval) + \
           "Model Saving Path (Relative): {}\n".format(self.save_model_path) + \
           "Epoch Save Start Prefix: {}\n".format(self.epoch_save_start_suffix) + \
           "Epoch Save End Suffix: {}\n".format(self.epoch_save_end_suffix) + \
           "Number of Clients: {}\n".format(self.num_workers) + \
           "Number of Poisoned Clients: {}\n".format(self.num_poisoned_workers) + \
           "NN model/net: {}\n".format(self.model) + \
           "Train Data Loader Path: {}\n".format(self.train_data_loader_pickle_path) + \
           "Test Data Loader Path: {}\n".format(self.test_data_loader_pickle_path) + \
           "Loss Function: {}\n".format(self.loss_function) + \
           "Default Model Folder Path: {}\n".format(self.default_model_folder_path) + \
           "Data Path: {}\n".format(self.data_path) + \
           "Number of edges: {}\n".format(self.num_edges) + \
           "Fraction of participated clients: {}\n".format(self.frac) + \
           "Number of communication: {}\n".format(self.num_communication) + \
           "Number of local update t1: {}\n".format(self.num_local_update) + \
           "Number of edge aggregation t2: {}\n".format(self.num_edge_aggregation) + \
           "Distribution of the data iid: {}\n".format(self.iid) + \
           "Is attack present 0 (NO) 1 (YES): {}\n".format(self.isattack) + \
           "Distribution of the data under edges, 1 (edgeiid),0 (edgeniid) (used only when iid = -2: {}\n".format(self.edgeiid) + \
           "Show distribution: {}\n".format(self.show_dis)


