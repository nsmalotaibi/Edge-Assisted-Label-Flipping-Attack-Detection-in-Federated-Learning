from arguments import Arguments
from federated_learning.nets import Cifar10CNN
from federated_learning.nets import Cifar100CNN
from federated_learning.nets import FashionMNISTCNN
from federated_learning.nets import MNISTCNN
from federated_learning.nets import Cifar10DenseNet
import os
import torch
from loguru import logger

if __name__ == '__main__':
    args = Arguments(logger)
    if not os.path.exists(args.get_default_model_folder_path()):
        os.mkdir(args.get_default_model_folder_path())

    # ---------------------------------
    # ----------- Cifar10CNN ----------
    # ---------------------------------
    full_save_path = os.path.join(args.get_default_model_folder_path(), "Cifar10CNN.model")
    torch.save(Cifar10CNN().state_dict(), full_save_path)
    # full_save_path = os.path.join(args.get_default_model_folder_path(), "Cifar10DenseNet.model")
    # torch.save(Cifar10DenseNet().state_dict(), full_save_path)

    # ---------------------------------
    # -------- FashionMNISTCNN --------
    # ---------------------------------
    full_save_path = os.path.join(args.get_default_model_folder_path(), "FashionMNISTCNN.model")
    torch.save(FashionMNISTCNN().state_dict(), full_save_path)

    # ---------------------------------
    # ----------- Cifar100CNN ----------
    # ---------------------------------
    full_save_path = os.path.join(args.get_default_model_folder_path(), "Cifar100CNN.model")
    torch.save(Cifar100CNN().state_dict(), full_save_path)

    # ---------------------------------
    # -------- MNISTCNN --------
    # ---------------------------------
    full_save_path = os.path.join(args.get_default_model_folder_path(), "MNISTCNN.model")
    torch.save(MNISTCNN().state_dict(), full_save_path)