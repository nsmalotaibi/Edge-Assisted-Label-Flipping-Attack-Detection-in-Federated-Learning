# Flow of the algorithm
# Client update(t_1) -> Edge Aggregate(t_2) -> Cloud Aggregate(t_3)

import os
import copy

import torch
import numpy as np

from tqdm import tqdm
from loguru import logger
from collections import defaultdict
from tensorboardX import SummaryWriter

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> System Components >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
from client import Client
from edge import Edge
from cloud import Cloud

from federated_learning.datasets.get_data import get_dataloaders
from federated_learning.nets import Cifar10CNN, Cifar100CNN, FashionMNISTCNN, MNISTCNN, Cifar10DenseNet

from Edge_Assisted_Detection import Edge_Assisted_Detection_Start, find_large_negative_discrepancies

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> general experiment utils>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
from experiment_utils import prepare_experiment_files, setup_device, log_device_info, setup_logger, \
    calculate_percentage_malicious, create_experiment_info, write_experiment_details_to_file, \
    initialize_metrics_before_training, log_global_performance_metrics, log_edge_recall, log_cloud_level_recall, \
    log_epoch_accuracies, save_epoch_accuracies_to_excel

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> detection utils>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
from detection_utils import handle_client_detections, print_client_accuracy_and_discrepancies_edge, \
    log_client_accuracy_and_discrepancies_edge, log_detection_accuracy_info, \
    update_and_print_detection_accuracy_metrics, detection_accuracy_edge_level, \
    log_all_accuracies_and_discrepancies_to_file, log_detection_accuracy_cloud_level

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Label flipping attack>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
from arguments import Arguments
from federated_learning.utils import identify_random_elements
from federated_learning.utils.poison_data import poison_data_new

from federated_learning.datasets.IID_and_NIID import get_client_class, initialize_edges_iid, initialize_edges_niid
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Efficiency>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
from federated_learning.utils.Sum_avg_efficiency import efficiency_metrics_for_epoch, start_processing, end_processing, \
    calculate_time_metrics, gather_resource_usage, update_epoch_edge_efficiency_metrics, \
    log_updated_epoch_edge_efficiency_metrics, log_epoch_efficiency_metrics
import time
import psutil

# >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> General plotting >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
from federated_learning.utils.general_plotting import plot_Identified_vs_Actual_Malicious_Clients_over_epochs, \
    plot_performance_metrics_of_2steps_detection_over_epochs, plot_each_class_wise_comparisons_separately, \
    plot_accuracy_per_client, plot_combined_accuracy, plot_accuracy_epochs, \
    plot_edge_clients_class_comparisons_for_all_classes, plot_class_specific_recall, \
    plot_discrepancies_separately, plot_discrepancies_for_all_classes, plot_Identified_vs_Actual_Malicious_Clients


def get_client_data(client, num_samples=100):
    data, target = next(iter(client.train_loader))
    return data[:num_samples], target[:num_samples]


def all_clients_test(server, clients, cids, device):
    """
    Tests models on each client using the shared state from the server and summarizes the results.

    The function initiates by sending the server's model state to each client identified in cids.
    Clients update their models with this state and then test these updated models on their local datasets.
    The test results, including the number of correct predictions and total tested items, are aggregated across clients.
    Additionally, class precision and recall metrics are calculated for each client.
    The function returns the aggregated test results, including the total number of correct predictions,
    total items tested, class precision, class recall, and the accuracy per client,
    thereby assessing the shared model's performance across different clients' data.

    :param server: The Edge server instance.
    :param clients: Dictionary of client instances.
    :param cids: List of client IDs to test.
    :param device: The device (CPU or GPU) for testing.
    :return: Aggregated test results, class precision, class recall, and accuracy per client.
    """
    accuracy_per_client = {}
    total_correct = 0
    total_samples = 0
    class_precision_edge = []
    class_recall_edge = []

    for cid in cids:
        server.send_to_client(clients[cid])
        clients[cid].sync_with_edgeserver()

        correct, total, class_precision, class_recall = clients[cid].test()
        total_correct += correct  # Sum of correct predictions across clients
        total_samples += total  # Sum of total predictions across clients
        print(f"Client {cid}: Correct - {correct}, Total - {total}")

        # Calculate and store accuracy percentage for individual client
        accuracy_percentage = 100 * correct / total if total > 0 else 0
        accuracy_per_client[cid] = accuracy_percentage

        class_precision_edge.extend(class_precision)
        class_recall_edge.extend(class_recall)

    # Return overall correct and total counts, along with other metrics
    return total_correct, total_samples, class_precision_edge, class_recall_edge, accuracy_per_client


def fast_all_clients_test(v_test_loader, global_nn, device):
    """
    Evaluate the global model's accuracy on a test dataset.

    Tests the global model by processing batches from the test set, comparing predictions to actual labels.
    It operates in evaluation mode, conserving resources by not tracking gradients.
    The function returns the total correct predictions and items tested.

    :param v_test_loader: DataLoader providing batches of test data and labels.
    :param global_nn: The global neural network model to be evaluated.
    :param device: The device (CPU or GPU) where the model should be evaluated.
    :return: A tuple containing the total number of correct predictions and the total number of items
    """
    correct_all = 0.0
    total_all = 0.0
    with torch.no_grad():
        for data in v_test_loader:
            inputs, labels = data
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = global_nn(inputs)
            _, predicts = torch.max(outputs, 1)
            total_all += labels.size(0)
            correct_all += (predicts == labels).sum().item()
    return correct_all, total_all


def calculate_performance_metrics_global(v_test_loader, model, device):
    model.eval()

    all_targets = []
    all_predictions = []

    with torch.no_grad():
        for (images, labels) in v_test_loader:
            images, labels = images.to(device), labels.to(device)

            outputs = model(images)
            _, predictions = torch.max(outputs, 1)

            all_targets.extend(labels.cpu().numpy())
            all_predictions.extend(predictions.cpu().numpy())

    # Calculate overall metrics
    g_accuracy = accuracy_score(all_targets, all_predictions)
    # average can be weighted = calculations accounts for class imbalance by weighting the metric by the number of true instances for each class.
    # or e.g., average='macro', average='micro').
    g_precision = precision_score(all_targets, all_predictions, average='weighted')
    g_recall = recall_score(all_targets, all_predictions, average='weighted')
    g_f1 = f1_score(all_targets, all_predictions, average='weighted')

    # Calculate class-specific recall
    class_specific_recall = recall_score(all_targets, all_predictions, average=None)

    # Detailed classification report (optional)
    g_class_report = classification_report(all_targets, all_predictions)

    return g_accuracy, g_precision, g_recall, g_f1, class_specific_recall, g_class_report


def initialize_global_nn(args):
    model_map = {
        'Cifar10CNN': Cifar10CNN,
        'MNISTCNN': MNISTCNN,
        'FashionMNISTCNN': FashionMNISTCNN,
        'Cifar100CNN': Cifar100CNN,
        'Cifar10DenseNet': Cifar10DenseNet
    }

    # Check if args.model is a class type and get its name
    model_name = args.model.__name__ if isinstance(args.model, type) else args.model
    model_class = model_map.get(model_name)

    if model_class:
        global_nn = model_class()
    else:
        valid_models = ', '.join(model_map.keys())
        raise ValueError(f"Invalid model name '{model_name}'. Valid models are: {valid_models}")

    return global_nn


def run_exp(replacement_method, num_poisoned_workers, experiment_id):
    # Prepare files and directories for the experiment
    log_file, results_dir = prepare_experiment_files(experiment_id)

    # Initialize logger
    setup_logger(log_file)
    args = Arguments(logger)
    args.set_num_poisoned_workers(num_poisoned_workers)
    args.set_replacement_method(replacement_method)
    args.log()

    # Device and directory setup
    device = setup_device(args.seed, args.cuda)
    log_device_info(logger, device)
    args.set_device(device)

    args.get_logger().info(f"{args.dataset}_clients{args.num_clients}_edges{args.num_edges}_" \
                           f"t1-{args.num_local_update}_t2-{args.num_edge_aggregation}" \
                           f"_model_{args.model}iid{args.iid}edgeiid{args.edgeiid}epoch{args.num_communication}" \
                           f"bs{args.batch_size}")

    FILEOUT = f"{args.dataset}_clients{args.num_clients}_edges{args.num_edges}_" \
              f"t1-{args.num_local_update}_t2-{args.num_edge_aggregation}" \
              f"iid{args.iid}edgeiid{args.edgeiid}epoch{args.num_communication}" \
              f"bs{args.batch_size}lr{args.lr}" \
              f"momentum{args.momentum}"
    writer = SummaryWriter(comment=FILEOUT)
    # ..............

    # Build dataloaders
    train_loaders, test_loaders, validation_loader, v_test_loader = get_dataloaders(args)

    # Apply LFA
    poisoned_workers = identify_random_elements(args.get_num_clients(), args.get_num_poisoned_workers())
    poisoned_train_loaders = poison_data_new(logger, train_loaders, args.get_num_clients(), poisoned_workers,
                                             replacement_method)

    # initialize clients and server
    clients = []
    for i in range(args.num_clients):
        clients.append(Client(client_idx=i,
                              train_loader=poisoned_train_loaders[i],
                              test_loader=test_loaders[i],
                              args=args,
                              device=device)
                       )

    initilize_parameters = list(clients[0].model.parameters())
    nc = len(initilize_parameters)
    for client in clients:
        args.get_logger().info("Initilizing on client #{}", str(client.get_client_index()))
        user_parameters = list(client.model.parameters())
        for i in range(nc):
            user_parameters[i].data[:] = initilize_parameters[i].data[:]

    # Initialize edge server and assign clients to the edge server
    edges = []
    cids = np.arange(args.num_clients)
    clients_per_edge = int(args.num_clients / args.num_edges)
    p_clients = [0.0] * args.num_edges

    if args.iid == -2:  # Assign each client samples of one class
        # `initialize_edges_iid()` results in a balanced and uniform data distribution across edge servers,
        # the data distribution among the edges is designed to be independent and identically distributed (IID).
        # In this setup, each edge has users from all classes, making the data distribution at each edge similar.
        if args.edgeiid == 1:
            client_class_dis = get_client_class(args, clients)
            print("client_class_dis after get_client_class: ", client_class_dis)
            edges, p_clients = initialize_edges_iid(num_edges=args.num_edges,
                                                    clients=clients,
                                                    args=args,
                                                    client_class_dis=client_class_dis)
        # whereas `initialize_edges_niid()` results in an unbalanced and non-uniform data distribution,
        # This function therefore distributes the clients across the edges in such a way that each edge contains a
        # subset of the classes of data, and clients with data of a specific class are distributed across different edges.
        elif args.edgeiid == 0:
            client_class_dis = get_client_class(args, clients)
            print("client_class_dis after get_client_class: ", client_class_dis)
            edges, p_clients = initialize_edges_niid(num_edges=args.num_edges,
                                                     clients=clients,
                                                     args=args,
                                                     client_class_dis=client_class_dis)
    else:
        # This is randomly assign the clients to edges
        for i in range(args.num_edges):
            # Randomly select clients and assign them
            selected_cids = np.random.choice(cids, clients_per_edge, replace=False)
            cids = list(set(cids) - set(selected_cids))
            edges.append(Edge(id=i,
                              cids=selected_cids,
                              model=copy.deepcopy(clients[0].model),
                              args=args,
                              validation_loader=validation_loader,
                              ))
            [edges[i].client_register(clients[cid]) for cid in selected_cids]
            edges[i].all_trainsample_num = sum(edges[i].sample_registration.values())
            p_clients[i] = [sample / float(edges[i].all_trainsample_num) for sample in
                            list(edges[i].sample_registration.values())]
            edges[i].refresh_edgeserver()
    # Initialize cloud server
    cloud = Cloud(model=copy.deepcopy(clients[0].model))

    # First the clients report to the edge server their training samples
    [cloud.edge_register(edge=edge) for edge in edges]
    p_edge = [sample / sum(cloud.sample_registration.values()) for sample in
              list(cloud.sample_registration.values())]
    cloud.refresh_cloudserver()
    # Initialize malicious client tracking
    malicious_client_count_per_edge = {edge.id: 0 for edge in edges}
    total_clients_per_edge = {edge.id: len(edge.cids) for edge in edges}

    # Count the number of malicious clients per edge
    for edge in edges:
        for cid in edge.cids:
            if cid in poisoned_workers:
                malicious_client_count_per_edge[edge.id] += 1

    all_edges_identified_malicious_clients = []
    for edge in edges:
        for client in clients:
            if client.client_idx not in poisoned_workers:
                edge.set_baseline_model(client.model)
                break

    # New an NN model for testing error
    global_nn = initialize_global_nn(args)
    if args.cuda:
        global_nn = global_nn.to(device)

    ##................
    folder_to_save_txt = "results/Experiments_Details"
    discrepancy_threshold = args.discrepancy_detection_threshold
    # Calculate the percentage of malicious clients
    percentage_malicious = calculate_percentage_malicious(num_poisoned_workers, args.num_clients)

    exp_info = create_experiment_info(args, experiment_id, num_poisoned_workers, poisoned_workers,
                                      replacement_method, percentage_malicious)

    file_path = write_experiment_details_to_file("results/Experiments_Details", experiment_id, exp_info, edges,
                                                 malicious_client_count_per_edge, total_clients_per_edge,
                                                 percentage_malicious,
                                                 discrepancy_threshold)

    metrics = initialize_metrics_before_training(args.num_edges, 10)

    # Begin training
    for epoch in tqdm(range(0, args.num_communication + 1)):
        cloud.refresh_cloudserver()
        [cloud.edge_register(edge=edge) for edge in edges]
        args.get_logger().info("Communication established: epoch number #{} ", str(epoch))

        # Initialize sub-dictionary for the epoch if not exists
        if epoch not in metrics['detection_performance_metrics']:
            metrics['detection_performance_metrics'][epoch] = {}

        # >>>>>>>>>>>K2 >>>>>>>>>>>>
        for num_edgeagg in range(args.num_edge_aggregation):
            edge_loss = [0.0] * args.num_edges
            edge_sample = [0] * args.num_edges
            correct_all = 0.0
            total_all = 0.0

            # Initialize malicious_client_info_per_edge for this epoch
            malicious_client_info_per_edge = {}
            edge_class_recall = {}  # Dictionary to store class recall for each edge
            edge_overall_recall = {}  # Dictionary to store overall recall for each edge

            for i, edge in enumerate(edges):
                edge.refresh_edgeserver()
                performance_dict_edge = {}  # Initialize an empty dictionary for each edge
                discrepancies = {}  # Initialize an empty dictionary to hold discrepancies for all clients
                # Initialize or reset the client_logs list for the current edge
                client_logs = []
                client_loss = 0.0
                selected_cnum = max(int(clients_per_edge * args.frac), 1)
                selected_cids = np.random.choice(edge.cids,
                                                 selected_cnum,
                                                 replace=False,
                                                 p=p_clients[i])

                # Initialize a dictionary to store gradients for all clients under the same edge
                edge_clients_gradients = {}
                actual_malicious_clients = set(poisoned_workers)  # Convert list to set
                # initialized before client loop
                all_client_accuracies = {}
                malicious_clients_large_negative_discrepancies = []

                for selected_cid in selected_cids:
                    args.get_logger().info("Client #{} registered with edge #{}", str(selected_cid),
                                           str(edges[edge.id].get_edge_id()))
                    edge.client_register(clients[selected_cid])

                for selected_cid in selected_cids:
                    edge.send_to_client(clients[selected_cid])
                    clients[selected_cid].sync_with_edgeserver()
                    args.get_logger().info("Client #{} perform local model training", str(selected_cid))

                    # would initially be a copy of the aggregated model received from the edge server.
                    # This model acts as a baseline or starting point for evaluating the impact of the client's local training during that epoch.
                    edge_model_client_model_before_train_the_received = copy.deepcopy(clients[selected_cid].model)
                    edge_model_class_accuracies = edge.calculate_class_accuracy(
                        edge_model_client_model_before_train_the_received, validation_loader, args)

                    # Ensure that edge_class_accuracies for this edge is a dictionary of class accuracies
                    metrics['edge_class_accuracies'][edge.id] = edge_model_class_accuracies

                    # training
                    client_loss, client_gradients = clients[selected_cid].train(epoch=epoch,
                                                                                num_local_update=args.num_local_update)
                    # Collect gradients for this client
                    # edge_clients_gradients[selected_cid] = client_gradients
                    args.get_logger().info("Client #{} sent the trained *local model* to the registered edge #{}",
                                           str(selected_cid),
                                           str(edges[edge.id].get_edge_id()))
                    clients[selected_cid].send_to_edgeserver(edge)

                    # # Initialize resource measurement before processing any clients
                    resources_before = start_processing()

                    # Edge_Assisted_Detection start
                    Edge_Assisted_Detection_Start(edge, clients, selected_cid, validation_loader, args, metrics,
                                                  all_client_accuracies, edge_model_class_accuracies, discrepancies,
                                                  performance_dict_edge)
                    print("nnnnnnnnnnnnnnnnnnnnnnnnnnn")

                    # 1-
                    client_accuracies = all_client_accuracies.get(selected_cid, {})
                    # Calculate discrepancies for each class
                    discrepancies[selected_cid] = edge.compare_classwise_accuracies({selected_cid: client_accuracies},
                                                                                    edge_model_class_accuracies)[
                        selected_cid]

                    # 2-
                    large_negative_discrepancies = find_large_negative_discrepancies(discrepancies, selected_cid,
                                                                                     args.discrepancy_detection_threshold)

                    # 3-
                    # detection time recording and latency calculation
                    communication_time, processing_time, detection_latency = calculate_time_metrics(edge, selected_cid,
                                                                                                    resources_before)
                    # Complete resource measurement after processing all clients
                    # Calculate resource usage differences and store metrics
                    resources_after = end_processing(resources_before)

                    # Access gpu_before and gpu_after from the resources
                    gpu_before = resources_before['gpu_before']
                    gpu_after = resources_after['gpu_after']

                    # 4-
                    resource_usage = gather_resource_usage(resources_before, resources_after)

                    handle_client_detections(file_path, selected_cid, detection_latency, large_negative_discrepancies,
                                             malicious_clients_large_negative_discrepancies,
                                             all_edges_identified_malicious_clients)

                    # Inside the loop, after calculating metrics
                    update_epoch_edge_efficiency_metrics(metrics, epoch, edge, resource_usage,
                                                         communication_time, processing_time, detection_latency)

                    log_updated_epoch_edge_efficiency_metrics(file_path, epoch, edge, resource_usage, gpu_before,
                                                              gpu_after,
                                                              communication_time, processing_time, detection_latency)

                    # 4 refresh
                    # plot_each_class_wise_comparisons_separately(edge_to_clients_accuracies, edge_class_accuracies, 'results/discrepancies_resulted_plots/class_wise_separately', experiment_id, epoch)
                    # plot_edge_clients_class_comparisons_for_all_classes(edge_to_clients_accuracies, edge_class_accuracies, 'results/discrepancies_resulted_plots/class_wise_All', experiment_id, epoch)
                    plot_each_class_wise_comparisons_separately(
                        metrics['edge_to_clients_accuracies'],
                        metrics['edge_class_accuracies'],
                        'results/discrepancies_resulted_plots/class_wise_separately',
                        experiment_id,
                        epoch
                    )

                    plot_edge_clients_class_comparisons_for_all_classes(
                        metrics['edge_to_clients_accuracies'],
                        metrics['edge_class_accuracies'],
                        'results/discrepancies_resulted_plots/class_wise_All',
                        experiment_id,
                        epoch
                    )
                    plot_discrepancies_separately(discrepancies, poisoned_workers,
                                                  'results/discrepancies_resulted_plots/adiscrepancies_separately',
                                                  experiment_id, edge.id, epoch)

                    plot_discrepancies_for_all_classes(discrepancies, poisoned_workers,
                                                       'results/discrepancies_resulted_plots/adiscrepancies_for_all_classes',
                                                       experiment_id, edge.id, epoch)

                #########################

                edge_loss[i] += client_loss
                edge_sample[i] = sum(edge.sample_registration.values())

                # # Print client accuracies and discrepancies under the current edge
                print_client_accuracy_and_discrepancies_edge(edge, performance_dict_edge, discrepancies)
                log_client_accuracy_and_discrepancies_edge(file_path, edge, edge_model_class_accuracies,
                                                           performance_dict_edge,
                                                           discrepancies)

                # Step 1: Initial detection using standard deviation
                # Update and get malicious client info for the current edge
                malicious_info = detection_accuracy_edge_level(
                    edge, performance_dict_edge, malicious_clients_large_negative_discrepancies,
                    selected_cids, actual_malicious_clients, malicious_client_info_per_edge
                )

                # Update metrics and print them
                update_and_print_detection_accuracy_metrics(
                    edge, epoch, malicious_info[edge.get_edge_id()], metrics,
                    actual_malicious_clients, selected_cids
                )

                # Log detection accuracy information
                # Write the performance metrics at the edge level
                log_detection_accuracy_info(
                    file_path, epoch, selected_cids, malicious_info[edge.get_edge_id()],
                    metrics['detection_performance_metrics'][epoch][edge.get_edge_id()]
                )

                # ###########################################################################
                # # writing the table into txt file too
                log_all_accuracies_and_discrepancies_to_file(file_path, edge, performance_dict_edge, discrepancies)

                # Store the malicious client info for this epoch
                metrics['epoch_edge_malicious_counts'][epoch] = malicious_client_info_per_edge
                # metrics['epoch_edge_malicious_counts'][epoch][edge.get_edge_id()] = malicious_client_info_per_edge

                args.get_logger().info(
                    "Edge#{} perform aggregation to obtain **edge models** based on the *local models* from its clients",
                    str(edge.get_edge_id()))
                # edge.aggregate(args)
                edge.aggregate_excluding(args, exclude_clients=malicious_clients_large_negative_discrepancies)

                correct_edge, total_edge, class_precision_edge, class_recall_edge, accuracy_per_client = all_clients_test(
                    edge, clients, edge.cids, device)
                # Update aggregated metrics
                correct_all += correct_edge
                total_all += total_edge
                metrics['class_precision_all_edges'].extend(class_precision_edge)
                metrics['class_recall_all_edges'].extend(class_recall_edge)
                print(f"After Edge {edge.get_edge_id()}: Correct All - {correct_all}, Total All - {total_all}")

                # Aggregate recall values for each class across all clients
                class_recall_aggregated = defaultdict(list)
                for recall_array in class_recall_edge:
                    for class_index, recall_value in enumerate(recall_array):
                        class_recall_aggregated[class_index].append(recall_value)

                # Calculate class-specific recall for this edge
                # Calculate average recall for each class at the edge level
                edge_recall = {class_index: np.mean(recalls) for class_index, recalls in
                               class_recall_aggregated.items()}

                # Calculate overall average class recall at the edge level
                average_recall_edge = np.mean([np.mean(recalls) for recalls in class_recall_aggregated.values()])

                # Store the recalls for this edge
                edge_class_recall[edge.get_edge_id()] = edge_recall
                edge_overall_recall[edge.get_edge_id()] = average_recall_edge
                # # Print and write class-specific and overall recall for this edge
                log_edge_recall(file_path, edge, edge_recall, average_recall_edge)

                for cid in accuracy_per_client.keys():
                    clients[cid].accuracy_per_epoch[epoch] = accuracy_per_client[cid]

                # end interation in edges
                # After processing all edges within the epoch, visualize the data

            # Calculate the overall training loss and average accuracy
            all_loss = sum([e_loss * e_sample for e_loss, e_sample in zip(edge_loss, edge_sample)]) / sum(edge_sample)
            print(f"Training Loss and Testing Accuracy at Epoch: {epoch}")
            print(f"Correct All: {correct_all}")
            print(f"Total All: {total_all}")
            if total_all > 0:
                avg_acc = 100 * correct_all / total_all
                metrics['epoch_accuracies'].append(avg_acc)  # Use the list within metrics
                metrics['epoch_numbers'].append(epoch)
                print(f"Overall Accuracy avg_acc: {avg_acc:.2f}%")
            else:
                print("No samples to evaluate.")
                avg_acc = 0
                metrics['epoch_accuracies'].append(0)  # Use the list within metrics
                metrics['epoch_numbers'].append(epoch)
            with open(file_path, "a") as file:
                file.write("-" * 100 + "\n")  # Separator
                file.write(f"\nTraining Loss and Testing Accuracy at Epoch {epoch}:\n")
                file.write(f"Overall Training Loss: {all_loss:.4f}\n")
                file.write(f"Average Testing Accuracy avg_acc: {avg_acc:.2f}%\n")  # Format as a percentage
                file.write("-" * 100 + "\n")  # Separator

            # Log the metrics to TensorBoard
            # to keep track of the loss and accuracy after each edge aggregation
            writer.add_scalar('Partial_Avg_Train_loss', all_loss, epoch * args.num_edge_aggregation + num_edgeagg + 1)
            writer.add_scalar('All_Avg_Test_Acc_edgeagg', avg_acc, epoch * args.num_edge_aggregation + num_edgeagg + 1)
            # a simpler view of how loss changes per epoch
            writer.add_scalar('Partial_Avg_Train_loss2', all_loss, epoch)
            writer.add_scalar('All_Avg_Test_Acc_edgeagg2', avg_acc, epoch)
            # After loop over edges, calculate average recalls at the cloud level
            average_recall_all_edges = np.mean(list(edge_overall_recall.values()))
            average_recall_per_class_all_edges = {
                class_index: np.mean([recalls.get(class_index, 0) for recalls in edge_class_recall.values()])
                for class_index in range(10)  # Replace with the actual number of classes
            }

            # # Print and write these averages at cloud level
            log_cloud_level_recall(file_path, average_recall_all_edges, average_recall_per_class_all_edges)


        # Now begin the cloud aggregation
        for edge in edges:
            args.get_logger().info("Edge #{} sent the **edge model** to the cloud for cloud aggregation",
                                   str(edge.get_edge_id()))
            edge.send_to_cloudserver(cloud)

        args.get_logger().info(
            "Cloud server conducts global aggregation based on the aggregated edge models to obtain the ***global model***")
        cloud.aggregate(args)
        # Generate all_client_ids based on args.num_clients
        all_client_ids = list(range(args.num_clients))
        # Calculate the performance metrics at the cloud level
        tpr, fpr, accuracy_of_correctly, tp, fp, fn, tn, all_malicious_identified = cloud.correctly_identified_malicious_clients_metrics(
            all_edges_identified_malicious_clients,
            poisoned_workers,
            all_client_ids
        )

        # # Print the performance metrics at the cloud level
        log_detection_accuracy_cloud_level(file_path, epoch, tp, fp, fn, tn, tpr, fpr, accuracy_of_correctly,
                                           all_malicious_identified)

        # Ensure the directory for plots exists
        save_directory_over_epochs = './results/Malicious_Clients_Trends_Plots'
        os.makedirs(save_directory_over_epochs, exist_ok=True)

        for edge in edges:
            args.get_logger().info(
                f"Cloud releases down the aggregated ***global model*** to edge #{edge.get_edge_id()}")
            cloud.send_to_edge(edge)

        # Load the global model state dict from the cloud and set it to evaluation mode
        global_nn.load_state_dict(state_dict=copy.deepcopy(cloud.model_state_dict))
        global_nn.train(False)  # Set the model to evaluation mode .eval()

        # Evaluate the global model performance for overall accuracy
        correct_all_v, total_all_v = fast_all_clients_test(v_test_loader, global_nn, device)
        avg_acc_v = 100 * correct_all_v / total_all_v
        metrics['epoch_accuracies_global'].append(avg_acc_v)  # Use the list within metrics
        metrics['epoch_numbers_global'].append(epoch)
        writer.add_scalar('All_Avg_Test_Acc_cloudagg_Vtest', avg_acc_v, epoch)

        # Calculate comprehensive performance metrics for the global model
        g_accuracy, g_precision, g_recall, g_f1, class_specific_recall, g_class_report = calculate_performance_metrics_global(
            v_test_loader,
            global_nn,
            device)
        # Call logging function
        log_global_performance_metrics(
            file_path, epoch, avg_acc_v, g_accuracy, g_precision, g_recall, g_f1,
            class_specific_recall, g_class_report, average_recall_per_class_all_edges, average_recall_all_edges
        )

        # Log and write the metrics to TensorBoard and output file
        writer.add_scalar('Global_Model_Accuracy', g_accuracy, epoch)
        writer.add_scalar('Global_Model_Precision', g_precision, epoch)
        writer.add_scalar('Global_Model_Recall', g_recall, epoch)
        writer.add_scalar('Global_Model_F1_Score', g_f1, epoch)

        # refresh
        plot_class_specific_recall(class_specific_recall, 'results/class_specific_recall_plots', experiment_id, epoch)

        # Log the final comprehensive metrics
        final_message = f"Global Model Performance at Epoch {epoch} - Overall Accuracy avg_acc_v: {avg_acc_v:.2%}, Accuracy g_accuracy: {g_accuracy:.2%}, Precision: {g_precision:.2%}, Recall: {g_recall:.2%}, F1 Score: {g_f1:.2%}"
        args.get_logger().info(final_message)

        # Generate plots for client and system-wide analysis
        plot_accuracy_per_client(clients, results_dir, experiment_id)
        plot_combined_accuracy(clients, results_dir, experiment_id)
        plot_Identified_vs_Actual_Malicious_Clients_over_epochs(
            metrics['epoch_edge_malicious_counts'], save_directory_over_epochs,
            experiment_id, percentage_malicious
        )

        plot_performance_metrics_of_2steps_detection_over_epochs(
            metrics['detection_performance_metrics'], save_directory_over_epochs,
            experiment_id, percentage_malicious
        )

        # Update and display the plot after each epoch
        plot_accuracy_epochs(
            metrics['epoch_accuracies'], metrics['epoch_numbers'],
            experiment_id, results_dir, percentage_malicious, "Training Accuracy"
        )

        plot_accuracy_epochs(
            metrics['epoch_accuracies_global'], metrics['epoch_numbers_global'],
            experiment_id, results_dir, percentage_malicious, "Global Test Accuracy"
        )

        # Final logging and closure
        print(final_message)
        writer.close()  # Close the TensorBoard writer

        log_epoch_accuracies(file_path, metrics)
        log_epoch_efficiency_metrics(file_path, metrics)

    save_epoch_accuracies_to_excel(metrics, experiment_id, args, percentage_malicious)

    # Close the TensorBoard writer
    writer.close()
    print(f"The final virtual acc is avg_acc_v {avg_acc_v}")
    args.get_logger().info("The final virtual acc avg_acc_v is {}", avg_acc_v)


def main():
    args = Arguments(logger)


if __name__ == '__main__':
    main()
