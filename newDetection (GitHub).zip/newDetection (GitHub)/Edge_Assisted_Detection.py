import copy


def Edge_Assisted_Detection_Start(edge, clients, selected_cid, validation_loader, args, metrics, all_client_accuracies,
                                  edge_model_class_accuracies, discrepancies, performance_dict_edge):


    # Load the client's model into a temporary model based on the edge's baseline model
    temp_model = copy.deepcopy(edge.baseline_model)
    temp_model.load_state_dict(clients[selected_cid].model.state_dict())

    # Measure overall and class-wise accuracy using the validation dataset
    overall_accuracy_on_validationDS = edge.validate_client_update_using_baseline_model(temp_model, validation_loader,
                                                                                        args)
    class_accuracies_on_validationDS = edge.calculate_class_accuracy(temp_model, validation_loader, args)

    # Store class-wise accuracies for the client
    all_client_accuracies[selected_cid] = class_accuracies_on_validationDS

    # Calculate and print discrepancies
    current_client_discrepancies = edge.compare_classwise_accuracies(
        {selected_cid: class_accuracies_on_validationDS}, edge_model_class_accuracies)
    discrepancies[selected_cid] = current_client_discrepancies[selected_cid]

    print_detection_details(selected_cid, edge_model_class_accuracies, overall_accuracy_on_validationDS,
                            class_accuracies_on_validationDS, discrepancies)

    # Store both accuracies and discrepancies associated with the client ID
    performance_dict_edge[selected_cid] = {
        "overall_accuracy_on_validationDS": overall_accuracy_on_validationDS,
        "class_accuracies_on_validationDS": class_accuracies_on_validationDS
    }

    # Store class-wise accuracies for the client within the edge
    if selected_cid not in metrics['edge_to_clients_accuracies'][edge.id]:
        metrics['edge_to_clients_accuracies'][edge.id][selected_cid] = {}
    metrics['edge_to_clients_accuracies'][edge.id][selected_cid] = class_accuracies_on_validationDS


def print_detection_details(selected_cid, edge_model_class_accuracies, overall_accuracy_on_validationDS,
                            class_accuracies_on_validationDS, discrepancies):
    # Print details about accuracies and discrepancies

    # Printing Edge Model Class-wise Accuracies
    print("\nEdge Model Class-wise Accuracies:")
    for class_id, accuracy in sorted(edge_model_class_accuracies.items(), key=lambda x: int(x[0])):
        print(f"Class ID: {class_id}, Accuracy: {accuracy:.3%}")
    # Separator for readability
    print("-" * 40)

    # Printing Overall and Class-wise Accuracies
    print(f"Client ID: {selected_cid}, Overall Accuracy: {overall_accuracy_on_validationDS:.3%}")
    for class_id, accuracy in sorted(class_accuracies_on_validationDS.items(), key=lambda x: int(x[0])):
        print(f"\tClass ID: {class_id}, Accuracy: {accuracy:.3%}")
    # Separator for readability
    print("-" * 40)

    # Printing Class-wise Discrepancies
    print(f"\nClass-Wise Discrepancies for Client {selected_cid}:")
    for class_id, discrepancy in sorted(discrepancies[selected_cid].items(), key=lambda x: int(x[0])):
        print(f"\tClass {class_id}: Discrepancy = {discrepancy:.3f}")
    # Final separator
    print("-" * 50)


def find_large_negative_discrepancies(discrepancies, selected_cid, threshold):
    discrepancies_for_client = discrepancies.get(selected_cid, {})
    return {
        class_id: value for class_id, value in discrepancies_for_client.items()
        if value < threshold
    }
