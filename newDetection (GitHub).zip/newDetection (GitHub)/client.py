# The structure of the client
# Should include following functions
# 1. Client initialization, dataloaders, model
# 2. Client train model
# 3. Client send updates to edge server
# 4. Client receives updates from edge server
# 5. Client modify local model based on the feedback from the edge server

from federated_learning.schedulers import MinCapableStepLR
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
import os
import numpy as np
import torch
import torch.optim as optim
import copy
import time


class Client():

    def __init__(self, args, client_idx, train_loader, test_loader, device):
        self.args = args
        self.client_idx = client_idx
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.device = self.initialize_device()
        self.set_model(self.load_default_model())
        self.loss_function = self.args.get_loss_function()()
        self.optimizer = optim.SGD(self.model.parameters(),
                                   lr=self.args.get_learning_rate(),
                                   momentum=self.args.get_momentum())
        self.scheduler = MinCapableStepLR(self.args.get_logger(), self.optimizer,
                                          self.args.get_scheduler_step_size(),
                                          self.args.get_scheduler_gamma(),
                                          self.args.get_min_lr())

        self.receiver_buffer = {}
        self.batch_size = args.batch_size
        self.num_local_update = self.args.num_local_update
        self.accuracy_per_epoch = {}
        self.epoch = 0
        self.clock = []

    def initialize_device(self):
        """
        Creates appropriate torch device for client operation.
        """
        if torch.cuda.is_available() and self.args.get_cuda():
            return torch.device("cuda:0")
        else:
            return torch.device("cpu")

    def set_model(self, model):
        """
        Set the client's NN.

        :param net: torch.nn
        """
        self.model = model
        self.model.to(self.device)

    def load_default_model(self):
        """
        Load a model from the default model file.

        This is used to ensure consistent default model behavior.
        """
        model_class = self.args.get_model()
        default_model_path = os.path.join(self.args.get_default_model_folder_path(), model_class.__name__ + ".model")

        return self.load_model_from_file(default_model_path)

    def load_model_from_file(self, model_file_path):
        """
        Load a model from a file.

        :param model_file_path: string
        """
        model_class = self.args.get_model()
        model = model_class()

        if os.path.exists(model_file_path):
            try:
                model.load_state_dict(torch.load(model_file_path))
            except:
                self.args.get_logger().warning(
                    "Couldn't load model. Attempting to map CUDA tensors to CPU to solve error.")

                model.load_state_dict(torch.load(model_file_path, map_location=torch.device('cpu')))
        else:
            self.args.get_logger().warning("Could not find model: {}".format(model_file_path))

        return model

    def get_client_index(self):
        """
        Returns the client index.
        """
        return self.client_idx

    def send_to_edgeserver(self, edgeserver):
        # Record the start time of sending the update
        self.send_time = time.time()
        # print(f"Client {self.client_idx} sent update at {self.send_time}")
        # Send the update (model_state_dict) to the edge server
        edgeserver.receive_from_client(client_id=self.client_idx,
                                       cmodel_state_dict=copy.deepcopy(self.model.state_dict()),
                                       send_time=self.send_time)
        return None

    def receive_from_edgeserver(self, model_state_dict):
        self.receiver_buffer = model_state_dict
        return None

    def sync_with_edgeserver(self):
        """
        The global has already been stored in the buffer
        :return: None
        """
        self.model.load_state_dict(self.receiver_buffer)
        return None

    def train(self, epoch, num_local_update):
        """
        Trains the model for a specified number of local updates (batches).

        :param epoch: Current epoch
        :param num_local_update: Number of local iterations (batches) to train for
        :return: Tuple of the total running loss and a list of gradients for each batch
        """
        self.model.train()
        gradients = []  # Initialize a list to store gradients for each batch
        running_loss = 0.0

        # save model at the start of the epoch if required
        if self.args.should_save_model(epoch):
            self.save_model(epoch, self.args.get_epoch_save_start_suffix())

        for local_iter in range(num_local_update):
            for i, (inputs, labels) in enumerate(self.train_loader, 0):
                inputs, labels = inputs.to(self.device), labels.to(self.device)

                # zero the parameter gradients
                self.optimizer.zero_grad()

                # forward pass
                outputs = self.model(inputs)
                loss = self.loss_function(outputs, labels)

                # backward pass
                loss.backward()

                # Collect gradients for each parameter before the optimizer step
                batch_gradients = {name: param.grad.clone().detach() for name, param in self.model.named_parameters() if
                                   param.grad is not None}
                gradients.append(batch_gradients)

                # update parameters
                self.optimizer.step()

                # accumulate loss
                running_loss += loss.item()
                if i % self.args.get_log_interval() == 0:
                    self.args.get_logger().info(
                        '[Epoch %d, Local Iter %d, Batch %5d] loss: %.3f' %
                        (epoch, local_iter, i + 1, running_loss / self.args.get_log_interval()))
                    running_loss = 0.0

        # Adjust the learning rate if needed
        self.scheduler.step()

        # save model at the end of the epoch if required
        if self.args.should_save_model(epoch):
            self.save_model(epoch, self.args.get_epoch_save_end_suffix())

        return running_loss, gradients

    def test(self):
        self.model.eval()

        correct = 0
        total = 0
        targets_ = []
        pred_ = []
        loss = 0.0
        class_precision = []  # Store class precision for each batch
        class_recall = []  # Store class recall for each batch

        with torch.no_grad():
            for (images, labels) in self.test_loader:
                images, labels = images.to(self.device), labels.to(self.device)

                outputs = self.model(images)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

                targets_.extend(labels.cpu().view_as(predicted).numpy())
                pred_.extend(predicted.cpu().numpy())

                loss += self.loss_function(outputs, labels).item()

                # Calculate class-level precision and recall for this batch
                batch_confusion_mat = confusion_matrix(labels.cpu(), predicted.cpu())
                batch_class_precision = self.calculate_class_precision(batch_confusion_mat)
                batch_class_recall = self.calculate_class_recall(batch_confusion_mat)

                class_precision.append(batch_class_precision)  # Append class precision for this batch
                class_recall.append(batch_class_recall)  # Append class recall for this batch

        accuracy = 100 * correct / total
        confusion_mat = confusion_matrix(targets_, pred_)
        self.args.get_logger().debug('Test set: Accuracy: {}/{} ({:.0f}%)'.format(correct, total, accuracy))
        self.args.get_logger().debug('Test set: Loss: {}'.format(loss))
        self.args.get_logger().debug("Classification Report:\n" + classification_report(targets_, pred_))
        self.args.get_logger().debug("Confusion Matrix:\n" + str(confusion_mat))

        return correct, total, class_precision, class_recall


    def calculate_class_precision(self, confusion_mat):
        """
        Calculates the precision for each class from a confusion matrix.
        """
        # Extract the diagonal elements (true positives) from the confusion matrix
        precision_numerator = np.diagonal(confusion_mat)

        # Compute the sum of each column (total predicted samples) in the confusion matrix
        precision_denominator = np.sum(confusion_mat, axis=0)

        # Handle division by zero by setting zero values to a small positive value
        precision_denominator = np.where(precision_denominator == 0, 1e-6, precision_denominator)

        # Calculate the precision for each class, setting zero_division=0
        precision = np.true_divide(precision_numerator, precision_denominator, where=precision_denominator != 0)

        # Return the calculated precisions for each class
        return precision

    def calculate_class_recall(self, confusion_mat):
        """
        Calculates the recall for each class from a confusion matrix.
        """
        # Extract the diagonal elements (true positives) from the confusion matrix
        recall_numerator = np.diagonal(confusion_mat)

        # Compute the sum of each row (total true samples) in the confusion matrix
        recall_denominator = np.sum(confusion_mat, axis=1)

        # Handle division by zero by setting zero values to a small positive value
        recall_denominator = np.where(recall_denominator == 0, 1e-6, recall_denominator)

        # Calculate the recall for each class
        recall = np.true_divide(recall_numerator, recall_denominator)

        # Return the calculated recalls for each class
        return recall

    def save_model(self, epoch, suffix):
        """
        Saves the model if necessary.
        """
        self.args.get_logger().debug("Saving model to flat file storage. Save #{}", epoch)

        if not os.path.exists(self.args.get_save_model_folder_path()):
            os.mkdir(self.args.get_save_model_folder_path())

        full_save_path = os.path.join(self.args.get_save_model_folder_path(),
                                      "model_" + str(self.client_idx) + "_" + str(epoch) + "_" + suffix + ".model")
        torch.save(self.model.state_dict(), full_save_path)
