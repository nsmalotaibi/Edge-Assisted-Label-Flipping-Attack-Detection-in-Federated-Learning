from federated_learning.utils import replace_0_with_2  # CIFAR-10
from federated_learning.utils import replace_1_with_3  # Fashion-MNIST
from federated_learning.utils import replace_7_with_9  # MNIST

from hierfavgattacked import run_exp

if __name__ == '__main__':
    START_EXP_IDX = 4
    NUM_EXP = 1
    NUM_POISONED_WORKERS = 15
    REPLACEMENT_METHOD = replace_1_with_3

    for experiment_id in range(START_EXP_IDX, START_EXP_IDX + NUM_EXP):
        run_exp(REPLACEMENT_METHOD, NUM_POISONED_WORKERS, experiment_id)
