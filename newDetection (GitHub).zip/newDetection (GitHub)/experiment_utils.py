import os
import torch
import numpy as np
import pandas as pd
from loguru import logger

from federated_learning.utils.Sum_avg_efficiency import initialize_total_counts, initialize_total_sums


def setup_logger(log_file):
    # Add new handler for the file
    logger.add(log_file, format="{time} {level} {message}", level="INFO", rotation="10 MB", enqueue=True)


def create_directory(directory_path):
    os.makedirs(directory_path, exist_ok=True)


def setup_device(seed, use_cuda):
    torch.manual_seed(seed)
    np.random.seed(seed)
    # Check if CUDA is available and set the device accordingly
    if use_cuda and torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        device = torch.device('cuda:0')
        torch.cuda.empty_cache()
    else:
        device = torch.device("cpu")
    return device


def log_device_info(logger, device):
    logger.info(f'Using Device: {device}')
    logger.info("Is CUDA Available: " + str(torch.cuda.is_available()))
    # logger.info("Num GPUs Available: " + str(torch.cuda.device_count()))
    # logger.info("Device Name: " + str(torch.cuda.get_device_name(0)))


def prepare_experiment_files(experiment_id):
    # Directory for results
    results_dir = f'results/plots/experiment_{experiment_id}'
    create_directory(results_dir)

    # Directory for logs
    log_dir = 'logs'
    create_directory(log_dir)
    log_file = f'{log_dir}/_{experiment_id}.log'
    return log_file, results_dir


def format_model_name(model):
    """ Remove the class path and only keep the actual class name """
    return str(model).split('.')[-1].replace("'>", "")


def calculate_percentage_malicious(num_poisoned_workers, num_clients):
    """ Calculate the percentage of malicious clients """
    percentage = (num_poisoned_workers / num_clients) * 100
    return round(percentage, 2)  # Round to two decimal places


def create_experiment_info(args, experiment_id, num_poisoned_workers, poisoned_workers, replacement_method,
                           percentage_malicious):
    """ Create and return the formatted experiment info string """
    model_name = format_model_name(args.model)
    return (f"Experiment Number : {experiment_id}\n"
            f"Dataset: {args.dataset}\n"
            f"Model: {model_name}\n"
            f"Number of Edges: {args.num_edges}\n"
            f"Number of Clients: {args.num_clients}\n"
            f"Number of poisoned workers: {num_poisoned_workers}\n"
            f"Poisoned workers: {poisoned_workers}\n"
            f"Percentage of Malicious Clients: {percentage_malicious:.2f}%\n"
            f"The replacement method: {replacement_method}\n"
            f"Discrepancy Detection Threshold: {args.discrepancy_detection_threshold}\n"
            f"Number of Local Updates (t1): {args.num_local_update}\n"
            f"Number of Edge Aggregations (t2): {args.num_edge_aggregation}\n"
            f"IID: {args.iid}\n"
            f"Edge IID: {args.edgeiid}\n"
            f"Number of Epochs: {args.num_communication}\n"
            f"Batch Size: {args.batch_size}\n"
            f"Learning Rate: {args.lr}\n"
            f"Momentum: {args.momentum}\n")


def write_experiment_details_to_file(folder_to_save, experiment_id, exp_info, edges, malicious_client_count_per_edge,
                                     total_clients_per_edge, percentage_malicious, discrepancy_threshold):
    """ Write the experiment information and details about malicious clients to a file """
    os.makedirs(folder_to_save, exist_ok=True)
    output_filename = (f"exp_{experiment_id}_"
                       f"pct_mal_{percentage_malicious}%_"
                       f"dd_thresh_{discrepancy_threshold}_"
                       f"client_accuracies_and_discrepancies.txt")
    file_path = os.path.join(folder_to_save, output_filename)

    with open(file_path, "w") as file:
        file.write("Starting new run...\n")
        file.write(exp_info)
        file.write("-" * 50 + "\n")
        file.write("Malicious Clients Information:\n")
        file.write("-" * 50 + "\n")
        for edge in edges:
            malicious_count = malicious_client_count_per_edge[edge.id]
            total_clients = total_clients_per_edge[edge.id]
            percentage = (malicious_count / total_clients) * 100
            file.write(
                f"Edge {edge.id} has {malicious_count} malicious clients out of {total_clients} ({percentage:.2f}%)\n")
        file.write("-" * 50 + "\n")
    return file_path  # Return the path of the file just written to
#
# def write_experiment_eff_to_file(folder_to_save, experiment_id, exp_info, edges, malicious_client_count_per_edge,
#                                      total_clients_per_edge, percentage_malicious, discrepancy_threshold):
#     """ Write the experiment information and details about malicious clients to a file """
#     os.makedirs(folder_to_save, exist_ok=True)
#     output_filename = (f"exp_{experiment_id}_"
#                        f"pct_mal_{percentage_malicious}%_"
#                        f"dd_thresh_{discrepancy_threshold}_"
#                        f"client_accuracies_and_discrepancies.txt")
#     file_path = os.path.join(folder_to_save, output_filename)
#
#     with open(file_path, "w") as file:
#         file.write("Starting new run...\n")
#         file.write(exp_info)
#         file.write("-" * 50 + "\n")
#         file.write("Malicious Clients Information:\n")
#         file.write("-" * 50 + "\n")
#         for edge in edges:
#             malicious_count = malicious_client_count_per_edge[edge.id]
#             total_clients = total_clients_per_edge[edge.id]
#             percentage = (malicious_count / total_clients) * 100
#             file.write(
#                 f"Edge {edge.id} has {malicious_count} malicious clients out of {total_clients} ({percentage:.2f}%)\n")
#         file.write("-" * 50 + "\n")
#     return file_path  # Return the path of the file just written to

def initialize_metrics_before_training(num_edges, num_classes):
    """ Initialize all necessary metrics and data structures for training """
    metrics = {
        'epoch_edge_malicious_counts': {},
        'detection_performance_metrics': {},
        'detection_efficiency_metrics': {},
        'class_precision_all_edges': [],
        'class_recall_all_edges': [],
        'epoch_accuracies': [],
        'epoch_numbers': [],
        'epoch_accuracies_global': [],
        'epoch_numbers_global': [],
        'edge_to_clients_accuracies': {edge_id: {} for edge_id in range(num_edges)},
        'edge_class_accuracies': {edge_id: {} for edge_id in range(num_edges)},
        'total_sums': initialize_total_sums(),
        'total_counts': initialize_total_counts(),
        'average_recall_per_class_all_edges': {class_index: 0 for class_index in range(num_classes)},
        'average_recall_all_edges': 0,
    }
    return metrics

def log_global_performance_metrics(file_path, epoch, avg_acc_v, g_accuracy, g_precision, g_recall, g_f1, class_specific_recall, g_class_report, average_recall_per_class_all_edges, average_recall_all_edges):
    """
    Log global model performance metrics to a specified file.

    :param file_path: Path to the file where metrics will be logged.
    :param epoch: The current epoch number.
    :param avg_acc_v: Average accuracy from fast_all_clients_test.
    :param g_accuracy, g_precision, g_recall, g_f1: Global accuracy, precision, recall, and F1 score.
    :param class_specific_recall: List of recall values for each class.
    :param g_class_report: Detailed classification report.
    :param average_recall_per_class_all_edges: Dictionary of average recall per class across all edges.
    :param average_recall_all_edges: Overall average class recall for all edges.
    """
    with open(file_path, "a") as file:
        file.write(f"\nGlobal Model Performance Metrics at Epoch {epoch}:\n")
        file.write(f"\n 1-Compare avg_acc_v and g_accuracy must be the same \n")
        file.write(f"Overall Accuracy avg_acc_v by fast_all_clients_test: {avg_acc_v:.2%}\n")
        file.write(f"Accuracy g_accuracy by calculate_performance_metrics_global: {g_accuracy:.2%}\n")
        file.write(f"2- Compare g_recall and average_recall_all_edges check what relation\n")
        file.write(f"Precision: {g_precision:.2%}\n")
        file.write(f"Recall g_recall: {g_recall:.2%}\n")
        file.write(f"F1 Score: {g_f1:.2%}\n")
        file.write(f"\nClassification Report:\n{g_class_report}\n")
        file.write("\nGlobal Model Class-Specific Recall:\n")
        file.write("\n 3- Compare class_specific_recall and average_recall_per_class_all_edges\n")
        for class_index, recall in enumerate(class_specific_recall):
            file.write(f"Class {class_index} Recall: {recall:.2f}\n")
        file.write("\nClass-Specific Recall by average_recall_per_class_all_edges:\n")
        for class_index, recall in average_recall_per_class_all_edges.items():
            file.write(f"Class {class_index} Recall: {recall:.2f}\n")
        file.write(
            f"\nOverall Average Class Recall for All Edges average_recall_all_edges: {average_recall_all_edges:.2f}\n")
        file.write("-" * 100 + "\n")  # Separator


def log_edge_recall(file_path, edge, edge_recall, average_recall_edge):
    """
    Logs class-specific and overall recall metrics for a given edge both to the console and to a file.

    :param file_path: Path to the log file.
    :param edge: The edge object, which must have a method get_edge_id() that returns its ID.
    :param edge_recall: Dictionary containing recall values for each class indexed by class.
    :param average_recall_edge: The overall average recall across all classes for the edge.
    """
    edge_id = edge.get_edge_id()
    print(f"\nEdge {edge_id} - Class-Specific and Overall Average Recall:")
    with open(file_path, "a") as file:
        file.write(f"\nEdge {edge_id} - Class-Specific and Overall Average Recall:\n")
        for class_index, recall_value in edge_recall.items():
            # Print each class's recall to console
            print(f"Class {class_index}: {recall_value:.2f}")
            # Write each class's recall to file
            file.write(f"Class {class_index}: {recall_value:.2f}\n")
        # Print and write overall recall
        print(f"Overall Average Recall: {average_recall_edge:.2f}")
        file.write(f"Overall Average Recall: {average_recall_edge:.2f}\n")
        # Write a separator line
        file.write("-" * 50 + "\n")

def log_cloud_level_recall(file_path, average_recall_all_edges, average_recall_per_class_all_edges):
    """
    Logs the average recall metrics at the cloud level to both the console and a file.

    :param file_path: Path to the log file where results will be written.
    :param average_recall_all_edges: The overall average recall across all edges.
    :param average_recall_per_class_all_edges: Dictionary containing recall values for each class across all edges.
    """
    print("------Cloud-level Recall Metrics-----")
    print(f"Average Recall for All Edges: {average_recall_all_edges:.2f}")
    print("Average Recall per Class for All Edges:")
    with open(file_path, "a") as file:
        file.write("-" * 100 + "\n")  # Separator
        file.write("\n------Cloud-level Recall Metrics-----\n")
        file.write(f"\nAverage Recall for All Edges: {average_recall_all_edges:.2f}\n")
        file.write("Average Recall per Class for All Edges:\n")
        for class_index, recall in average_recall_per_class_all_edges.items():
            # Print to console
            print(f"Class {class_index}: {recall:.2f}")
            # Write to file
            file.write(f"Class {class_index}: {recall:.2f}\n")
        file.write("-" * 100 + "\n")  # Separator


def log_epoch_accuracies(file_path, metrics):
    """
    Logs selected epochs and their accuracies for training and testing to a file.

    :param file_path: Path to the file where the accuracies will be logged.
    :param metrics: Dictionary containing metrics with keys 'epoch_numbers', 'epoch_accuracies',
                    'epoch_numbers_global', and 'epoch_accuracies_global'.
    """
    with open(file_path, "a") as file:
        # Log Training Accuracies
        file.write("\nSelected Epochs and Their Accuracies (Training):\n")
        file.write("-" * 100 + "\n")
        max_epoch = max(metrics['epoch_numbers']) if metrics['epoch_numbers'] else 0
        for epoch in range(0, max_epoch + 1, 10):  # Iterates over 0, 10, 20, ..., max
            if epoch < len(metrics['epoch_accuracies']):
                accuracy = metrics['epoch_accuracies'][epoch]
                file.write(f"Epoch {epoch}: Accuracy {accuracy:.2f}%\n")
        file.write("-" * 100 + "\n")

        # Log Testing Accuracies
        file.write("\nSelected Epochs and Their Accuracies (Testing):\n")
        file.write("-" * 100 + "\n")
        max_epoch_global = max(metrics['epoch_numbers_global']) if metrics['epoch_numbers_global'] else 0
        for epoch in range(0, max_epoch_global + 1, 10):
            if epoch < len(metrics['epoch_accuracies_global']):
                accuracy = metrics['epoch_accuracies_global'][epoch]
                file.write(f"Epoch {epoch}: Accuracy {accuracy:.2f}%\n")
        file.write("-" * 100 + "\n")

        # Log Detection Efficiency Metrics Summary
        file.write("Detection Efficiency Metrics Summary\n")
        file.write("=" * 50 + "\n")



def save_epoch_accuracies_to_excel(metrics, experiment_id, args,percentage_malicious):
    """
    Saves selected epochs' training and testing accuracies to an Excel file.

    :param metrics: Dictionary containing the metrics with keys 'epoch_numbers', 'epoch_accuracies',
                    and 'epoch_accuracies_global'.
    :param experiment_id: Identifier for the experiment.
    :param args: Configuration object or namespace containing additional options like dataset name and
                 percentage of malicious entries.
    """
    # Folder setup
    folder_name = 'results/epoch_accuracies'
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    # Calculate the selected epochs
    max_epoch = max(metrics['epoch_numbers']) if metrics['epoch_numbers'] else 0
    selected_epochs = list(range(0, max_epoch + 1, 10))

    # Fetch training and testing accuracies
    training_accuracies = [metrics['epoch_accuracies'][epoch] for epoch in selected_epochs if
                           epoch < len(metrics['epoch_accuracies'])]
    testing_accuracies = [metrics['epoch_accuracies_global'][epoch] for epoch in selected_epochs if
                          epoch < len(metrics['epoch_accuracies_global'])]

    # DataFrame construction
    df = pd.DataFrame({
        'Epoch': selected_epochs,
        'Training Accuracy': training_accuracies,
        'Testing Accuracy': testing_accuracies
    })

    # Construct file path for Excel output
    excel_file_path = f'./{folder_name}/epoch_accuracies_Exp{str(experiment_id)}_Dataset_{args.dataset}_M{str(percentage_malicious)}%.xlsx'

    # Write the DataFrame to an Excel file
    df.to_excel(excel_file_path, index=False)

    print(f"Data saved to {excel_file_path}")