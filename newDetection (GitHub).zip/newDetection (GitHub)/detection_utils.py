import time


def log_client_detection(file, client_id, latency, is_malicious):
    """Log detection latency for a client to a file and console."""
    status = "malicious" if is_malicious else "non-malicious"
    message = f"Detection latency for client {client_id} ({status}): {latency} seconds\n"
    print(message.strip())
    file.write(message)


def handle_client_detections(file_path, selected_cid, detection_latency, large_negative_discrepancies, malicious_clients, all_malicious_clients):
    """
    Process detections, log results, and return the updated list of malicious clients.

    :param file_path: Path to the file where results will be logged.
    :param selected_cid: Client ID being processed.
    :param detection_latency: Time it took to process the detection.
    :param large_negative_discrepancies: Dictionary of discrepancies that exceeded the threshold.
    :param malicious_clients: List of clients identified as malicious based on current detection.
    :param all_malicious_clients: Cumulative list of all identified malicious clients.
    :return: Updated list of malicious clients.
    """
    with open(file_path, "a") as file:
        if large_negative_discrepancies:
            malicious_clients.append(selected_cid)
            log_client_detection(file, selected_cid, detection_latency, True)
            all_malicious_clients.extend(malicious_clients)
        else:
            log_client_detection(file, selected_cid, detection_latency, False)



def print_client_accuracy_and_discrepancies_edge(edge, performance_dict_edge, discrepancies):
    print(f"\nAccuracies under Edge ID: {edge.get_edge_id()}")
    for client_id, accuracies in performance_dict_edge.items():
        overall_accuracy = accuracies["overall_accuracy_on_validationDS"]
        class_accuracies = accuracies["class_accuracies_on_validationDS"]
        class_discrepancies = discrepancies.get(client_id, {})  # Retrieve discrepancies for the current client

        # Print overall and class-wise accuracies
        print(f"Client ID: {client_id}, Overall Accuracy: {overall_accuracy:.3%}")
        for class_id, accuracy in sorted(class_accuracies.items()):
            print(f"\tClass ID: {class_id}, Accuracy: {accuracy:.3%}")

        # Print discrepancies
        print("\nClass-Wise Discrepancies for Client {}: ".format(client_id))
        for class_id, discrepancy in sorted(class_discrepancies.items()):
            print(f"\tClass {class_id}: Discrepancy = {discrepancy:.3f}")
        print("-" * 50)  # Separator for each client


def log_client_accuracy_and_discrepancies_edge(file_path, edge, edge_model_class_accuracies, performance_dict_edge, discrepancies):
    with open(file_path, "a") as file:
        file.write(f"Edge Model Class-wise Accuracies:\n")
        for class_id, accuracy in sorted(edge_model_class_accuracies.items(), key=lambda x: int(x[0])):
            class_accuracy_str = f"Class ID: {class_id}, Accuracy: {accuracy:.3%}\n"
            file.write(class_accuracy_str)

        file.write(f"\nAccuracies under Edge ID: {edge.get_edge_id()}\n")
        for client_id, accuracies in performance_dict_edge.items():
            overall_accuracy = accuracies["overall_accuracy_on_validationDS"]
            class_accuracies = accuracies["class_accuracies_on_validationDS"]
            class_discrepancies = discrepancies.get(client_id, {})

            file.write(f"Client ID: {client_id}, Overall Accuracy: {overall_accuracy:.3%}\n")
            for class_id, accuracy in sorted(class_accuracies.items()):
                file.write(f"\tClass ID: {class_id}, Accuracy: {accuracy:.3%}\n")

            file.write("\nClass-Wise Discrepancies for Client {}:\n".format(client_id))
            for class_id, discrepancy in sorted(class_discrepancies.items()):
                file.write(f"\tClass {class_id}: Discrepancy = {discrepancy:.3f}\n")
            file.write("-" * 50 + "\n")


def detection_accuracy_edge_level(edge, performance_dict_edge, malicious_clients_large_negative_discrepancies, selected_cids, actual_malicious_clients, malicious_client_info_per_edge):
    # Identify malicious clients based on standard deviation
    edge_malicious_clients_by_std_dev = edge.identify_malicious_clients_by_std_dev(performance_dict_edge)

    # Combine sets of malicious clients identified by different methods
    all_excluded_malicious_clients = set(edge_malicious_clients_by_std_dev + malicious_clients_large_negative_discrepancies)

    # Convert selected client IDs to a set for intersection
    selected_cids_set = set(selected_cids)
    # Intersection with actual malicious clients
    actual_set = actual_malicious_clients.intersection(selected_cids_set)

    # Ensure each key exists in the dictionary, even if as an empty list
    malicious_client_info_per_edge[edge.get_edge_id()] = {
        'flagged': list(edge_malicious_clients_by_std_dev) if edge_malicious_clients_by_std_dev else [],
        'confirmed': list(malicious_clients_large_negative_discrepancies) if malicious_clients_large_negative_discrepancies else [],
        'actual': list(actual_set) if actual_set else []
    }

    print("\nMalicious Client Detection:")
    print(f"All Client IDs under this edge: {selected_cids}")
    print(f"Identified Malicious Clients by std_dev: {edge_malicious_clients_by_std_dev}")
    print(f"Malicious Clients after discrepancy check: {malicious_clients_large_negative_discrepancies}")
    print(f"Actual Malicious Clients under the edge: {actual_set}")

    return malicious_client_info_per_edge


def update_and_print_detection_accuracy_metrics(edge, epoch, malicious_info, metrics, actual_malicious_clients, selected_cids):
    # Convert the list of selected client IDs into a set for further operations
    selected_cids_set = set(selected_cids)

    # Ensure that all necessary keys are present in the malicious_info dictionary before proceeding
    if 'flagged' in malicious_info and 'confirmed' in malicious_info and 'actual' in malicious_info:
        # Call the edge method to calculate detection metrics based on the provided malicious client data
        tpr, fpr, accuracy_of_correctly, tp, fp, fn, tn = edge.correctly_identified_malicious_clients_metrics(
            malicious_info['confirmed'], actual_malicious_clients, selected_cids_set
        )

        # Update the metrics dictionary for the current edge and epoch with the calculated metrics
        metrics['detection_performance_metrics'][epoch][edge.get_edge_id()] = {
            'tpr': tpr,
            'fpr': fpr,
            'accuracy': accuracy_of_correctly,
            'tp': tp,
            'fp': fp,
            'fn': fn,
            'tn': tn
        }

        # Print the metrics to the console for immediate visibility and verification
        print(f"Performance Metrics of Correctly Identified Malicious Clients at Edge Level: Edge = {edge.get_edge_id()}, Epoch = {epoch}")
        print(f"True Positives (TP): {tp}")
        print(f"False Positives (FP): {fp}")
        print(f"False Negatives (FN): {fn}")
        print(f"True Negatives (TN): {tn}")
        print(f"TPR/Recall/Sensitivity: {tpr:.3f}")
        print(f"FPR: {fpr:.3f}")
        print(f"Accuracy: {accuracy_of_correctly:.2%}")
    else:
        # If any of the necessary keys are missing, print an error message and do not attempt to update or print metrics
        print("Error: Missing expected keys in malicious_info dictionary. Ensure that 'flagged', 'confirmed', and 'actual' are present.")


def log_detection_accuracy_info(file_path, epoch, selected_cids, malicious_info, performance_metrics):
    with open(file_path, "a") as file:
        file.write("\nMalicious Client Detection:\n")
        file.write(f"At epoch: {epoch}\n")
        file.write(f"All Client IDs under this edge: {selected_cids}\n")
        file.write(f"Identified Malicious Clients by std_dev: {','.join(map(str, malicious_info.get('flagged', [])))}\n")
        file.write(f"Identified Malicious Clients by discrepancies: {','.join(map(str, malicious_info.get('confirmed', [])))}\n")
        file.write(f"Actual Malicious Clients under the edge: {','.join(map(str, malicious_info.get('actual', [])))}\n")

        file.write("\nPerformance Metrics of Correctly Identified Malicious Clients at Edge Level:\n")
        file.write(f"True Positives (TP): {performance_metrics.get('tp', 0)}\n")
        file.write(f"False Positives (FP): {performance_metrics.get('fp', 0)}\n")
        file.write(f"False Negatives (FN): {performance_metrics.get('fn', 0)}\n")
        file.write(f"True Negatives (TN): {performance_metrics.get('tn', 0)}\n")
        file.write(f"TPR/Recall/Sensitivity: {performance_metrics.get('tpr', 0) * 100:.2f}%\n")
        file.write(f"FPR: {performance_metrics.get('fpr', 0) * 100:.2f}%\n")
        file.write(f"Accuracy: {performance_metrics.get('accuracy', 0) * 100:.2f}%\n")
        file.write("-" * 50 + "\n")


def log_all_accuracies_and_discrepancies_to_file(file_path, edge, performance_dict_edge, discrepancies):
    # Define column widths for the table
    client_id_width = 10
    class_id_width = 10
    accuracy_width = 10
    discrepancy_width = 10

    with open(file_path, "a") as file:
        file.write(f"\nAccuracies and Discrepancies under Edge ID: {edge.get_edge_id()}\n")
        # Assuming edge.format_header_row formats the header row based on the given widths
        file.write(edge.format_header_row(client_id_width, class_id_width, accuracy_width, discrepancy_width))
        file.write("-" * (client_id_width + class_id_width + accuracy_width + discrepancy_width) + "\n")

        for client_id, accuracies in performance_dict_edge.items():
            class_accuracies = accuracies["class_accuracies_on_validationDS"]
            class_discrepancies = discrepancies.get(client_id, {})

            for class_id, accuracy in sorted(class_accuracies.items()):
                discrepancy = class_discrepancies.get(class_id, 'N/A')
                # Assuming edge.format_data_row formats each row of data based on the given widths and data
                row = edge.format_data_row(client_id, class_id, accuracy, discrepancy, client_id_width, class_id_width,
                                           accuracy_width, discrepancy_width)
                file.write(row)
        file.write("-" * (client_id_width + class_id_width + accuracy_width + discrepancy_width) + "\n")


def log_detection_accuracy_cloud_level(file_path, epoch, tp, fp, fn, tn, tpr, fpr, accuracy_of_correctly,
                                  all_malicious_identified):
    """
    Log and print cloud-level detection accuracy for correctly identified malicious clients.

    :param file_path: Path to the file where the metrics will be logged.
    :param epoch: The current epoch number.
    :param tp: True Positives count.
    :param fp: False Positives count.
    :param fn: False Negatives count.
    :param tn: True Negatives count.
    :param tpr: True Positive Rate or Recall.
    :param fpr: False Positive Rate.
    :param accuracy_of_correctly: Accuracy of correctly identified malicious clients.
    :param all_malicious_identified: Boolean indicating whether all actual malicious clients have been identified.
    """
    print(f"Performance Metrics detection accuracy of correctly_identified_malicious_clients at Cloud Level: at epoch: {epoch}")
    print(f"True Positives (TP): {tp}")
    print(f"False Positives (FP): {fp}")
    print(f"False Negatives (FN): {fn}")
    print(f"True Negatives (TN): {tn}")
    print(f"TPR/Recall/Sensitivity: {tpr:.3f}")
    print(f"FPR: {fpr:.3f}")
    print(f"Accuracy accuracy_of_correctly: {accuracy_of_correctly:.2%}")

    if all_malicious_identified:
        print(f"All actual malicious clients have been correctly identified at epoch {epoch}.")

    with open(file_path, "a") as file:
        file.write("\nPerformance Metrics detection accuracy of correctly_identified_malicious_clients at Cloud Level:\n")
        file.write(f"at epoch: {epoch}\n")
        file.write(f"True Positives (TP): {tp}\n")
        file.write(f"False Positives (FP): {fp}\n")
        file.write(f"False Negatives (FN): {fn}\n")
        file.write(f"True Negatives (TN): {tn}\n")
        tpr_percent = tpr * 100
        fpr_percent = fpr * 100
        file.write(f"TPR/Recall/Sensitivity: {tpr_percent:.2f}%\n")
        file.write(f"FPR: {fpr_percent:.2f}%\n")
        accuracy_percent = accuracy_of_correctly * 100  # Convert proportion to a percentage
        file.write(f"Accuracy accuracy_of_correctly: {accuracy_percent:.2f}%\n")  # Format to two decimal places
        if all_malicious_identified:
            file.write(f"All actual malicious clients have been correctly identified at epoch {epoch}.\n")
        file.write("-" * 100 + "\n")  # Separator
